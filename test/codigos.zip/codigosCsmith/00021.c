/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00021.c -s 00021 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      21
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   unsigned f0 : 9;
   signed f1 : 28;
};





static struct S0  func_1(void);





static struct S0  func_1(void)
{ 
    int16_t l_2[7];
    int32_t l_3 = 0L;
    int32_t l_14 = 0x5761AC7EL;
    int32_t l_27 = (-1L);
    int64_t l_30 = 1L;
    int32_t l_31 = 0x8E188A74L;
    int32_t l_34 = 0x36FA7ABEL;
    int32_t l_36 = (-1L);
    int32_t l_37 = (-5L);
    int32_t l_39 = (-4L);
    int32_t l_40 = (-9L);
    uint16_t l_43 = 0xC683L;
    int64_t l_63[9] = {0xB2634890B8A2E7C9LL,0x1AE9EC2B408DBE58LL,0xB2634890B8A2E7C9LL,0xB2634890B8A2E7C9LL,0x1AE9EC2B408DBE58LL,0xB2634890B8A2E7C9LL,0xB2634890B8A2E7C9LL,0x1AE9EC2B408DBE58LL,0xB2634890B8A2E7C9LL};
    int16_t l_69 = (-7L);
    struct S0 l_74 = {9,11835};
    int i;
    for (i = 0; i < 7; i++)
        l_2[i] = 1L;
    for (l_3 = 4; (l_3 >= 0); l_3 -= 1)
    { 
        int16_t l_4 = 0xA522L;
        struct S0 l_10 = {8,7205};
        int32_t l_22 = 0x2AFBCAE2L;
        int32_t l_23 = (-6L);
        int32_t l_24[8] = {7L,(-1L),7L,(-1L),7L,(-1L),7L,(-1L)};
        int8_t l_66 = 0x26L;
        int8_t l_67 = 0x74L;
        uint16_t l_71[3];
        int i;
        for (i = 0; i < 3; i++)
            l_71[i] = 0UL;
        l_4 = 0xAF8B5131L;
        for (l_4 = 0; l_4 < 7; l_4 += 1)
        {
            l_2[l_4] = 0xA92BL;
        }
        if ((safe_mul_func_uint32_t_u_u((((safe_div_func_uint8_t_u_u(246UL, 0x95L)) == l_2[l_3]) | l_3), l_2[l_3])))
        { 
            struct S0 l_9 = {7,-5789};
            l_9 = l_9;
            l_10 = l_9;
        }
        else
        { 
            uint16_t l_13 = 0x3413L;
            int32_t l_19 = 0x52324067L;
            int32_t l_21 = 0x9AF3922CL;
            int32_t l_26 = 0xBD3D38E2L;
            int32_t l_28 = 0x4DAD2401L;
            int32_t l_32 = 0L;
            int32_t l_33[6] = {1L,7L,7L,1L,7L,7L};
            int8_t l_38[4];
            int16_t l_41 = 5L;
            int i;
            for (i = 0; i < 4; i++)
                l_38[i] = 0xDCL;
            if ((((safe_mul_func_uint16_t_u_u((l_13 < l_3), l_13)) && 250UL) > 0xE0752570L))
            { 
                l_14 = (0x7FB0L ^ 7L);
                l_19 |= (safe_add_func_int16_t_s_s(((safe_add_func_int64_t_s_s(l_4, 0x589D38951FE511BDLL)) || l_14), 65534UL));
                l_10.f1 = l_19;
            }
            else
            { 
                struct S0 l_20 = {17,-2600};
                int32_t l_25 = (-3L);
                int32_t l_29 = 0xD54BA4FDL;
                int32_t l_35 = 0x2A909F00L;
                int32_t l_42[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                int i;
                l_20 = l_10;
                l_10.f1 = l_14;
                l_43--;
            }
            l_10.f1 = (safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((((safe_sub_func_int8_t_s_s((((((safe_div_func_int16_t_s_s(0L, l_39)) | l_2[l_3]) <= l_26) <= l_34) | l_28), 0xF0L)) != l_28) || l_2[l_3]), l_38[0])), 0L));
            l_36 = ((safe_sub_func_uint16_t_u_u((~l_38[0]), 0xBA45L)) >= 0x1F86L);
            for (l_22 = 6; (l_22 >= 1); l_22 -= 1)
            { 
                const int16_t l_64 = (-1L);
                int32_t l_65[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                int32_t l_68 = 0xC6491A58L;
                int32_t l_70 = 5L;
                struct S0 l_75 = {16,-184};
                int i;
                l_33[2] = (safe_mod_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((safe_add_func_uint16_t_u_u((((l_63[5] < (-9L)) && l_24[1]) >= l_64), l_36)), 0x617FL)), 1L));
                l_71[0]++;
                l_32 &= l_2[4];
                l_75 = l_74;
            }
        }
        l_10 = l_74;
    }
    return l_74;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 36
   depth: 1, occurrence: 5
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 5
breakdown:
   indirect level: 0, occurrence: 5
XXX full-bitfields structs in the program: 5
breakdown:
   indirect level: 0, occurrence: 5
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 5
XXX times a bitfields struct on RHS: 6
XXX times a single bitfield on LHS: 3
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 32
XXX times a non-volatile is write: 18
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6
   depth: 3, occurrence: 10

XXX percentage a fresh-made variable is used: 31.8
XXX percentage an existing variable is used: 68.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

