/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00041.c -s 00041 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      41
 */

#include "csmith.h"


static long __undefined;






static uint8_t  func_1(void);





static uint8_t  func_1(void)
{ 
    uint64_t l_4 = 0UL;
    uint32_t l_5 = 0xEC541651L;
    int8_t l_35 = 0x48L;
    int32_t l_36 = 7L;
    int32_t l_39[8] = {7L,0x3C9534CEL,7L,7L,0x3C9534CEL,7L,7L,0x3C9534CEL};
    int16_t l_56 = 0x6C71L;
    int8_t l_96 = 1L;
    uint32_t l_118 = 3UL;
    int32_t l_143[7] = {3L,(-7L),(-7L),3L,(-7L),(-7L),3L};
    int64_t l_144 = (-1L);
    int32_t l_145 = 0x90676B53L;
    int8_t l_146 = (-1L);
    int64_t l_147 = 0xF79F888D3F9E7EE7LL;
    int64_t l_148 = 1L;
    uint32_t l_149 = 0UL;
    int8_t l_153[4] = {0xAAL,0xAAL,0xAAL,0xAAL};
    uint64_t l_162[4] = {1UL,1UL,1UL,1UL};
    int64_t l_167 = 0L;
    int16_t l_168 = 0xA15FL;
    int i;
    if ((safe_mod_func_int32_t_s_s(((l_4 < 0x57BFL) < 8UL), l_4)))
    { 
        uint32_t l_13[5];
        int32_t l_22 = (-1L);
        int32_t l_41 = 0x46CB4F5FL;
        int32_t l_42 = (-1L);
        int32_t l_46 = (-6L);
        int32_t l_47 = 0L;
        uint32_t l_49 = 0x5D5FCA44L;
        uint32_t l_85 = 18446744073709551608UL;
        int32_t l_99 = (-7L);
        int32_t l_101 = 0x8DA357BBL;
        int32_t l_105 = 1L;
        int32_t l_107 = (-1L);
        int32_t l_108 = (-1L);
        int32_t l_110 = (-9L);
        int32_t l_111 = (-1L);
        int32_t l_112[2];
        int i;
        for (i = 0; i < 5; i++)
            l_13[i] = 0x9B76EEA5L;
        for (i = 0; i < 2; i++)
            l_112[i] = 5L;
        if (l_5)
        { 
            int8_t l_14[10] = {0x1EL,0L,0L,0x1EL,0L,0L,0x1EL,0L,0L,0x1EL};
            int32_t l_17 = (-1L);
            int i;
            for (l_4 = 20; (l_4 >= 13); l_4 = safe_sub_func_int64_t_s_s(l_4, 1))
            { 
                uint32_t l_12[6];
                int i;
                for (i = 0; i < 6; i++)
                    l_12[i] = 0x4D1454BCL;
                l_14[8] ^= ((safe_lshift_func_int16_t_s_u((safe_lshift_func_int64_t_s_s(l_12[4], 52)), l_4)) || l_13[2]);
                l_17 = ((safe_div_func_uint64_t_u_u(l_4, l_12[4])) >= 0xB445ACEE61780EECLL);
                l_22 = (safe_lshift_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(((l_12[4] || 0x37L) >= l_12[4]), 0L)), 18));
            }
            return l_22;
        }
        else
        { 
            int32_t l_30[3];
            int32_t l_31 = 2L;
            int32_t l_33 = 0xF7673ED1L;
            int32_t l_34 = 1L;
            int32_t l_37 = (-6L);
            int32_t l_43 = 0L;
            int32_t l_44 = 0xD469F41AL;
            int64_t l_69 = 0x26993C4D9805F634LL;
            const int32_t l_77 = 1L;
            uint16_t l_78[5];
            int i;
            for (i = 0; i < 3; i++)
                l_30[i] = (-2L);
            for (i = 0; i < 5; i++)
                l_78[i] = 7UL;
            for (l_5 = 0; (l_5 > 43); l_5++)
            { 
                int16_t l_27 = 0x718BL;
                int32_t l_28 = 0x585FAFE4L;
                int32_t l_29 = 0x87B35F19L;
                int32_t l_32 = 0x99E68FC7L;
                int32_t l_38 = 7L;
                int32_t l_40[8] = {0x95534FD3L,(-4L),0x95534FD3L,(-4L),0x95534FD3L,(-4L),0x95534FD3L,(-4L)};
                int32_t l_45 = 0xA49E864AL;
                int32_t l_48[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_48[i] = (-3L);
                l_28 |= (safe_lshift_func_int32_t_s_u(l_27, l_4));
                l_49--;
            }
            l_31 = 0xD6B9EC49L;
            if ((safe_add_func_uint8_t_u_u(((safe_mul_func_uint64_t_u_u(l_43, l_5)) & l_56), 0x14L)))
            { 
                int64_t l_57 = 0x40931BC1F9C85207LL;
                int32_t l_60 = 0x6FDE0027L;
                l_57 = (0UL >= 0UL);
                l_60 = (safe_sub_func_uint8_t_u_u(l_37, l_46));
                l_31 = (safe_mod_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(l_34, l_57)), 0x56A74AB72231B3DFLL));
            }
            else
            { 
                uint32_t l_70 = 1UL;
                l_70 = (safe_lshift_func_uint8_t_u_s((safe_mod_func_uint8_t_u_u(l_69, 0x7FL)), 5));
                l_42 = ((safe_div_func_int64_t_s_s(l_39[2], 0xD599618DE77BF6B3LL)) != l_70);
                l_34 = ((safe_mul_func_uint32_t_u_u(((safe_sub_func_int32_t_s_s((l_77 > l_42), 0xB071CE90L)) != (-3L)), l_78[4])) < l_78[4]);
                l_85 = (safe_lshift_func_int32_t_s_s(((safe_div_func_int64_t_s_s(((safe_add_func_int8_t_s_s(((l_39[3] < 0xE763FF6366113C50LL) != l_37), l_70)) ^ l_13[3]), l_34)) > l_39[5]), 28));
            }
        }
        l_39[1] = 0xD3A61860L;
        for (l_5 = (-30); (l_5 >= 24); l_5 = safe_add_func_int64_t_s_s(l_5, 1))
        { 
            int32_t l_92 = 2L;
            int32_t l_93 = 1L;
            int32_t l_97[8];
            int i;
            for (i = 0; i < 8; i++)
                l_97[i] = 7L;
            for (l_47 = 7; (l_47 >= 2); l_47 -= 1)
            { 
                int i;
                return l_39[l_47];
            }
            for (l_41 = 0; (l_41 >= (-10)); l_41--)
            { 
                int8_t l_94 = 0L;
                int32_t l_95 = 0x29709749L;
                int32_t l_98 = (-5L);
                int32_t l_100 = 0x928B54DFL;
                int32_t l_102 = 0x79EF6EAEL;
                int32_t l_103 = 1L;
                int32_t l_104 = 0xE02F5F5CL;
                int32_t l_106 = 0x07748211L;
                int32_t l_109 = 0xCDDCCF37L;
                int32_t l_113 = (-7L);
                int32_t l_114 = 0x6F079C5DL;
                uint16_t l_115 = 0x5A05L;
                l_93 = (safe_mul_func_uint64_t_u_u(l_92, 1L));
                l_115++;
                l_118--;
                l_97[7] &= (safe_lshift_func_uint64_t_u_s(((safe_lshift_func_uint32_t_u_u((((safe_sub_func_int32_t_s_s(l_93, 4UL)) != 0xFA7B1138347E9BEELL) && 1UL), 20)) != l_112[1]), l_107));
            }
            return l_39[3];
        }
    }
    else
    { 
        int64_t l_127 = 2L;
        int32_t l_128 = 0L;
        int32_t l_129 = 0x18E49B9DL;
        int32_t l_130 = (-6L);
        int32_t l_131 = 6L;
        int16_t l_132 = 1L;
        int32_t l_133 = (-1L);
        int32_t l_134 = 0x83ECD636L;
        int32_t l_135 = 0L;
        int32_t l_136 = 0x3574D0E4L;
        int32_t l_137 = (-1L);
        int32_t l_138 = 0x288A0B6DL;
        int32_t l_139 = 7L;
        int32_t l_140 = (-1L);
        int32_t l_141 = 0xF6D39C23L;
        int32_t l_142[8] = {0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L,0xE20E3AF3L};
        int8_t l_152 = 1L;
        int i;
        l_149++;
        for (l_148 = 0; (l_148 <= 7); l_148 += 1)
        { 
            int i;
            if ((((((((l_142[l_148] >= 0xFFL) <= 4294967295UL) & l_142[l_148]) > l_142[l_148]) < l_39[l_148]) ^ l_39[l_148]) != l_143[1]))
            { 
                int i;
                l_142[l_148] = (((l_152 > l_153[0]) < 0x93F6A8FEL) || l_136);
                l_39[l_148] = (((((l_143[1] >= l_39[l_148]) < l_142[l_148]) >= 0xE53AA939E12E8AAELL) == l_142[l_148]) || l_39[l_148]);
            }
            else
            { 
                l_36 = 0x0405A668L;
            }
        }
        for (l_149 = (-12); (l_149 < 39); l_149 = safe_add_func_uint64_t_u_u(l_149, 1))
        { 
            int16_t l_158 = 0xA726L;
            for (l_96 = (-2); (l_96 != (-14)); l_96 = safe_sub_func_int32_t_s_s(l_96, 6))
            { 
                return l_158;
            }
        }
    }
    l_162[2] &= (!(safe_lshift_func_int64_t_s_u(((((l_153[0] == 65535UL) | l_56) & (-10L)) && l_118), l_35)));
    l_39[3] = l_4;
    l_167 = ((((safe_div_func_int64_t_s_s(((((safe_sub_func_uint16_t_u_u(7UL, 65535UL)) >= l_39[3]) < 18446744073709551615UL) == l_39[3]), l_162[0])) < l_153[0]) || l_162[1]) ^ l_143[1]);
    return l_168;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 92
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 39
   depth: 2, occurrence: 12
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 74
XXX times a non-volatile is write: 33
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 42
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 6
   depth: 2, occurrence: 10
   depth: 3, occurrence: 21

XXX percentage a fresh-made variable is used: 37.7
XXX percentage an existing variable is used: 62.3
XXX total OOB instances added: 0
********************* end of statistics **********************/

