/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00038.c -s 00038 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      38
 */

#include "csmith.h"


static long __undefined;


struct S1 {
   uint64_t  f0;
   uint64_t  f1;
   uint16_t  f2;
   uint32_t  f3;
   int32_t  f4;
   const int64_t  f5;
   uint8_t  f6;
};

struct S4 {
   uint64_t  f0;
};





static struct S1  func_1(void);





static struct S1  func_1(void)
{ 
    int64_t l_2[9];
    int32_t l_3 = (-1L);
    int32_t l_9[8] = {0x0714BA09L,(-5L),0x0714BA09L,0x0714BA09L,(-5L),0x0714BA09L,0x0714BA09L,(-5L)};
    struct S4 l_11 = {0xCE9B8A514227F44FLL};
    uint16_t l_31 = 0xF60DL;
    struct S1 l_48[4] = {{18446744073709551615UL,18446744073709551615UL,0xF057L,0x0DC05481L,0L,1L,0xDBL},{18446744073709551615UL,18446744073709551615UL,0xF057L,0x0DC05481L,0L,1L,0xDBL},{18446744073709551615UL,18446744073709551615UL,0xF057L,0x0DC05481L,0L,1L,0xDBL},{18446744073709551615UL,18446744073709551615UL,0xF057L,0x0DC05481L,0L,1L,0xDBL}};
    int i;
    for (i = 0; i < 9; i++)
        l_2[i] = 0L;
    l_3 = (l_2[1] >= l_2[5]);
    if ((l_2[1] || l_2[6]))
    { 
        int64_t l_6 = 0L;
        struct S4 l_10[10] = {{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL},{0x127420EA1BCA3396LL}};
        int16_t l_17[3];
        int32_t l_18 = (-4L);
        int i;
        for (i = 0; i < 3; i++)
            l_17[i] = 0xE8F8L;
        l_6 |= ((safe_rshift_func_int8_t_s_u((247UL == l_2[1]), 4)) && l_3);
        for (l_3 = 8; (l_3 >= 0); l_3 -= 1)
        { 
            int32_t l_14[1];
            int i;
            for (i = 0; i < 1; i++)
                l_14[i] = 1L;
            l_9[2] = (((safe_mul_func_uint64_t_u_u((l_2[l_3] & l_6), l_2[l_3])) && l_2[l_3]) & l_2[6]);
            for (l_6 = 8; (l_6 >= 0); l_6 -= 1)
            { 
                l_11 = l_10[9];
                l_14[0] ^= (safe_mul_func_int64_t_s_s((0UL | 0UL), l_2[1]));
            }
            for (l_6 = 0; (l_6 <= 8); l_6 += 1)
            { 
                uint8_t l_19 = 255UL;
                l_9[2] = l_2[1];
                l_17[1] = (safe_mod_func_uint64_t_u_u(l_9[6], 2L));
                l_19--;
                l_18 = 0xEE8C4B05L;
            }
            l_9[2] = l_2[l_3];
        }
        for (l_18 = 0; (l_18 >= (-19)); l_18 = safe_sub_func_uint16_t_u_u(l_18, 9))
        { 
            struct S1 l_27 = {18446744073709551615UL,0xFC7BC07E7F6F8F64LL,0UL,4294967295UL,0x132D45ABL,-4L,1UL};
            for (l_11.f0 = 0; (l_11.f0 != 9); l_11.f0 = safe_add_func_int32_t_s_s(l_11.f0, 1))
            { 
                struct S4 l_26[5] = {{0xD35DF961DFA23986LL},{0xD35DF961DFA23986LL},{0xD35DF961DFA23986LL},{0xD35DF961DFA23986LL},{0xD35DF961DFA23986LL}};
                int i;
                l_26[4] = l_11;
                return l_27;
            }
            l_11 = l_10[9];
        }
    }
    else
    { 
        int16_t l_30 = (-2L);
        int32_t l_32 = (-7L);
        struct S4 l_38 = {0xA09F94EB44D5381DLL};
        l_3 = (safe_mod_func_uint32_t_u_u((l_30 > 4294967286UL), l_9[1]));
        l_32 = (((l_31 & l_30) != 0x00L) != l_30);
        for (l_3 = (-23); (l_3 == 19); l_3 = safe_add_func_uint64_t_u_u(l_3, 7))
        { 
            struct S4 l_39 = {0xBB921586CE7EF2A9LL};
            for (l_11.f0 = 0; (l_11.f0 < 56); l_11.f0 = safe_add_func_uint32_t_u_u(l_11.f0, 5))
            { 
                int64_t l_37 = 4L;
                l_9[4] = ((((l_9[2] >= 0UL) < l_37) || l_37) != l_2[1]);
                l_39 = l_38;
            }
            for (l_11.f0 = 0; (l_11.f0 <= 8); l_11.f0 += 1)
            { 
                uint64_t l_40[7];
                int i;
                for (i = 0; i < 7; i++)
                    l_40[i] = 0xF381B91F40AC15C2LL;
                l_40[6]--;
            }
            for (l_38.f0 = (-27); (l_38.f0 >= 24); l_38.f0 = safe_add_func_int8_t_s_s(l_38.f0, 1))
            { 
                struct S1 l_45 = {0xF4091208AFAEF9ADLL,0x5785F4F6E08938C4LL,0xCB2DL,4UL,0x65B034E2L,0x8D86F2FEC8B64E3CLL,252UL};
                return l_45;
            }
            for (l_31 = 0; (l_31 == 47); l_31 = safe_add_func_uint16_t_u_u(l_31, 7))
            { 
                l_39 = l_39;
            }
        }
    }
    return l_48[2];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 31
   depth: 2, occurrence: 13
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 42
XXX times a non-volatile is write: 28
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 32
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 6
   depth: 2, occurrence: 10
   depth: 3, occurrence: 13

XXX percentage a fresh-made variable is used: 40.4
XXX percentage an existing variable is used: 59.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

