/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00028.c -s 00028 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      28
 */

#include "csmith.h"


static long __undefined;






static uint32_t  func_1(void);





static uint32_t  func_1(void)
{ 
    int64_t l_2 = 1L;
    int8_t l_3[10] = {0xB8L,(-9L),8L,8L,(-9L),0xB8L,(-9L),8L,8L,(-9L)};
    int32_t l_4 = (-4L);
    int32_t l_27 = 0L;
    uint16_t l_55 = 1UL;
    int i;
    l_3[4] = (l_2 > l_2);
    l_4 ^= (((((l_3[4] ^ l_3[4]) > 0x8764L) || l_3[4]) != l_3[0]) || l_2);
    if ((safe_add_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u(0x4207L, l_3[6])), l_2)))
    { 
        int32_t l_22 = 0xE857B1A0L;
        int32_t l_28 = 1L;
        for (l_4 = 1; (l_4 <= 9); l_4 += 1)
        { 
            int8_t l_21 = 1L;
            int32_t l_23[6] = {8L,8L,0x857617C0L,8L,8L,0x857617C0L};
            int i;
            l_23[3] |= (safe_add_func_uint64_t_u_u(((safe_add_func_int64_t_s_s((safe_lshift_func_int32_t_s_u((((safe_mod_func_int64_t_s_s((safe_div_func_uint8_t_u_u((safe_add_func_int16_t_s_s(8L, 1L)), l_3[4])), 0x97F51EF9953E80C6LL)) && l_3[2]) <= l_4), 14)), 0UL)) >= l_21), l_22));
            if ((safe_mul_func_uint64_t_u_u(18446744073709551610UL, l_22)))
            { 
                int32_t l_26[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_26[i] = 0x131DDA87L;
                l_26[0] &= l_23[5];
                l_27 = 0xEA1B1489L;
                l_28 = 0x2796A450L;
            }
            else
            { 
                uint16_t l_37[10];
                int i;
                for (i = 0; i < 10; i++)
                    l_37[i] = 0x76E3L;
                l_28 = ((safe_add_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((safe_div_func_int16_t_s_s((((safe_div_func_uint32_t_u_u(0x39B398EFL, 0xBD1A6F32L)) ^ l_28) != 1UL), l_37[0])), 0UL)), l_37[7])) || l_22);
                l_23[2] = (-1L);
            }
            l_23[3] |= ((0xC9A81FFDL ^ 6L) & l_27);
        }
    }
    else
    { 
        int16_t l_54 = 0x2610L;
        int32_t l_56[2];
        uint32_t l_57 = 8UL;
        int i;
        for (i = 0; i < 2; i++)
            l_56[i] = 0xEC0DB1B7L;
        for (l_4 = 0; (l_4 == 25); l_4 = safe_add_func_int64_t_s_s(l_4, 8))
        { 
            const uint16_t l_53 = 0x2008L;
            for (l_27 = 1; (l_27 <= 9); l_27 += 1)
            { 
                int i;
                l_54 = (safe_sub_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((((safe_mod_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((((((safe_sub_func_int32_t_s_s((!(safe_div_func_uint8_t_u_u(l_3[l_27], l_3[4]))), l_3[l_27])) & 0x95372A71L) != l_3[6]) != l_3[l_27]) ^ 0L), 0x0FEFL)) < 1L), l_53)) <= l_2) == 0x21FD00955DF93C58LL), l_3[l_27])), 0UL));
                l_56[1] = ((l_27 & l_55) != l_53);
            }
        }
        l_4 = ((0x67L > l_56[1]) == l_57);
        for (l_54 = 9; (l_54 >= 3); l_54 -= 1)
        { 
            uint16_t l_58 = 4UL;
            int32_t l_80 = 1L;
            for (l_55 = 0; (l_55 <= 9); l_55 += 1)
            { 
                int i;
                l_58--;
                l_56[1] = (safe_mod_func_int16_t_s_s((safe_add_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(0x5FL, 3)), l_3[l_54])), 1UL));
                l_4 = (safe_mod_func_int16_t_s_s(((safe_unary_minus_func_int16_t_s((safe_sub_func_uint32_t_u_u(((safe_unary_minus_func_int8_t_s((((!(((safe_rshift_func_uint16_t_u_u((((safe_add_func_int64_t_s_s(0xC1C926A5A418E4AALL, l_3[l_54])) ^ 65535UL) <= 1UL), 0)) || 1L) | l_2)) || (-1L)) && l_27))) ^ l_3[l_54]), l_55)))) == l_27), l_56[1]));
            }
            for (l_4 = 0; (l_4 <= 1); l_4 += 1)
            { 
                int i;
                l_56[l_4] &= l_3[(l_4 + 4)];
                l_80 = ((((safe_rshift_func_int32_t_s_u((l_3[(l_4 + 2)] <= l_3[l_4]), 13)) > l_3[(l_4 + 6)]) & l_56[l_4]) | l_3[4]);
            }
        }
    }
    return l_3[4];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 8
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 55
XXX times a non-volatile is write: 23
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6
   depth: 3, occurrence: 12

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
XXX total OOB instances added: 0
********************* end of statistics **********************/

