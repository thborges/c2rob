/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00011.c -s 00011 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      11
 */

#include "csmith.h"


static long __undefined;






static int16_t  func_1(void);





static int16_t  func_1(void)
{ 
    int16_t l_10 = 0xD6C3L;
    uint32_t l_11 = 8UL;
    uint32_t l_12 = 1UL;
    int32_t l_13[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
    int i;
    l_13[5] = (safe_sub_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((((((((safe_div_func_uint8_t_u_u(l_10, l_10)) || l_11) | l_10) ^ l_11) != l_10) ^ l_11) <= l_12), 0xC7B7F609B2B534DELL)), 15)), l_10));
    return l_12;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 1
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 36.4
XXX percentage an existing variable is used: 63.6
XXX total OOB instances added: 0
********************* end of statistics **********************/

