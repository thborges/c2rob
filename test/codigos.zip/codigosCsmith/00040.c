/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00040.c -s 00040 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      40
 */

#include "csmith.h"


static long __undefined;






static const uint32_t  func_1(void);





static const uint32_t  func_1(void)
{ 
    uint32_t l_5 = 0x8B108F82L;
    int32_t l_6 = 0xC3EEE2FDL;
    uint32_t l_7[5];
    int32_t l_8[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
    const int32_t l_33 = 0L;
    uint32_t l_34 = 18446744073709551606UL;
    const uint64_t l_93 = 0xFFE4DFDC5D499989LL;
    int i;
    for (i = 0; i < 5; i++)
        l_7[i] = 0x7D65121AL;
    l_6 |= (+((safe_div_func_uint32_t_u_u(l_5, l_5)) | l_5));
    for (l_6 = 4; (l_6 >= 0); l_6 -= 1)
    { 
        int32_t l_11 = 0xD4A55F07L;
        int32_t l_19 = 7L;
        int i;
        l_8[2] = ((-1L) > l_7[l_6]);
        if ((safe_unary_minus_func_int16_t_s(l_7[l_6])))
        { 
            int8_t l_15[10];
            uint16_t l_18 = 0xAF7BL;
            int i;
            for (i = 0; i < 10; i++)
                l_15[i] = 5L;
            l_11 = (safe_unary_minus_func_int8_t_s(l_7[l_6]));
            for (l_11 = 4; (l_11 >= 0); l_11 -= 1)
            { 
                int32_t l_14 = 7L;
                l_15[0] = (((safe_sub_func_uint8_t_u_u(l_14, (-2L))) & 0x9576L) < 0UL);
                l_8[0] ^= ((safe_sub_func_int64_t_s_s(l_6, l_11)) | l_18);
                l_8[2] = l_19;
            }
            if ((safe_unary_minus_func_int16_t_s((safe_div_func_int8_t_s_s(((safe_div_func_int8_t_s_s((l_15[0] <= 0xA6B2C4EB0A117216LL), l_7[l_6])) | l_15[0]), 5UL)))))
            { 
                int32_t l_25 = (-1L);
                int32_t l_26 = 0x77FC7DF3L;
                l_26 ^= ((l_18 == l_8[2]) > l_25);
                return l_7[4];
            }
            else
            { 
                return l_18;
            }
        }
        else
        { 
            uint32_t l_35 = 0xC1B2D863L;
            for (l_19 = 0; (l_19 <= 4); l_19 += 1)
            { 
                int32_t l_31[4] = {(-7L),(-7L),(-7L),(-7L)};
                int i;
                l_31[1] ^= (safe_mul_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(l_8[(l_6 + 1)], l_8[(l_6 + 1)])), 7UL));
                l_8[2] = l_7[l_6];
                l_34 = ((safe_unary_minus_func_uint32_t_u((8UL | l_33))) | l_19);
                l_8[(l_6 + 1)] = ((0x4203L || l_35) && 1UL);
            }
            l_11 ^= (l_7[l_6] & 0x8791B167L);
            l_11 = (safe_rshift_func_int64_t_s_u(0x54C62B4191165901LL, 17));
        }
    }
    if ((safe_mul_func_uint16_t_u_u(((safe_mul_func_int64_t_s_s((-7L), 1UL)) != l_7[4]), l_34)))
    { 
        int16_t l_47 = 0xB058L;
        int32_t l_48 = 0x67B33DF1L;
        int32_t l_85 = 0x0FEFE548L;
        int32_t l_86 = 0x29D736D3L;
        int32_t l_87 = 0x5289E610L;
        int32_t l_88 = 0xB8ADFEA0L;
        int32_t l_89 = (-1L);
        uint32_t l_90[10] = {0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L,0xCFE06C79L};
        uint32_t l_115 = 0xF4AA1FF7L;
        int32_t l_124 = 0x01FB82FDL;
        int i;
        l_48 = (safe_mod_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u((!l_47), l_33)) | l_8[3]), 0x23L));
        if ((l_5 ^ 0x7C1FL))
        { 
            int8_t l_53 = 0x0CL;
            l_48 = (0xA0L || l_47);
            for (l_6 = 4; (l_6 >= 0); l_6 -= 1)
            { 
                int i;
                return l_7[l_6];
            }
            for (l_34 = 0; (l_34 > 35); l_34 = safe_add_func_int64_t_s_s(l_34, 1))
            { 
                int8_t l_54[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_54[i] = 0x46L;
                l_54[0] = (safe_mul_func_int32_t_s_s((l_48 == l_47), l_53));
            }
        }
        else
        { 
            int16_t l_64 = (-9L);
            int32_t l_84[2];
            int i;
            for (i = 0; i < 2; i++)
                l_84[i] = (-1L);
            if ((safe_lshift_func_int16_t_s_s((~(((safe_mul_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_rshift_func_uint64_t_u_u(((1L != l_64) & l_48), l_48)), l_6)), 0xB0L)) && 0x8A60B10F657D2A19LL) != 1UL)), l_48)))
            { 
                int32_t l_65[7] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
                int i;
                l_65[6] = l_47;
            }
            else
            { 
                uint32_t l_83 = 2UL;
                l_6 &= (safe_mod_func_int32_t_s_s((safe_mul_func_uint32_t_u_u((((((safe_div_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((safe_div_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((((((+(safe_mul_func_uint8_t_u_u(((0x8B2FL != l_83) | l_47), 0x78L))) < l_83) > l_83) != l_34) <= l_8[2]), 251UL)), l_47)), (-3L))), l_33)), l_64)) ^ 0x09879556L) <= l_48) != l_83) & 3UL), 0xBF13354AL)), l_83));
                return l_64;
            }
            l_90[2]++;
            return l_93;
        }
        for (l_87 = 12; (l_87 >= 15); l_87 = safe_add_func_uint64_t_u_u(l_87, 4))
        { 
            uint8_t l_106 = 0x2DL;
            uint16_t l_108[3];
            uint8_t l_126 = 0x3EL;
            int32_t l_141 = 0xEF7B2E30L;
            int i;
            for (i = 0; i < 3; i++)
                l_108[i] = 0x9B81L;
            for (l_89 = 0; (l_89 == 7); l_89 = safe_add_func_uint64_t_u_u(l_89, 3))
            { 
                int32_t l_103 = 0x03F0CD8BL;
                l_103 |= ((safe_mul_func_uint32_t_u_u((!(safe_mul_func_uint16_t_u_u(((-4L) <= l_5), l_5))), l_7[0])) > 0x7FL);
            }
            for (l_86 = 0; (l_86 < (-13)); l_86 = safe_sub_func_uint8_t_u_u(l_86, 6))
            { 
                uint64_t l_107 = 18446744073709551608UL;
                int32_t l_116 = (-1L);
                l_108[1] ^= ((l_90[4] >= l_106) ^ l_107);
                l_6 = ((safe_mul_func_int32_t_s_s((safe_div_func_int8_t_s_s(((safe_mul_func_int32_t_s_s(l_115, 0xE60D347FL)) || l_108[1]), 0xA9L)), 0x3F5A7A75L)) < 0xE5449298L);
                l_85 |= ((7UL || l_116) && 0xD51AL);
                l_116 |= ((+(l_108[1] >= l_106)) && l_86);
            }
            if ((l_108[2] > l_106))
            { 
                l_88 ^= 0xFA4877AAL;
            }
            else
            { 
                uint8_t l_125 = 8UL;
                l_8[2] = (safe_lshift_func_int64_t_s_u(((safe_lshift_func_uint16_t_u_s((safe_div_func_int32_t_s_s(l_124, l_108[1])), 14)) & l_125), l_126));
                l_89 ^= (safe_lshift_func_int32_t_s_u((safe_lshift_func_int16_t_s_u((safe_add_func_uint16_t_u_u((l_106 || 0x6226F77E7A5B985ALL), l_125)), l_48)), l_126));
                l_6 = ((((safe_mul_func_uint64_t_u_u((0x4994D0E7L ^ l_126), l_125)) || l_126) > l_106) ^ 8L);
                l_141 = (safe_sub_func_uint32_t_u_u(((safe_rshift_func_int64_t_s_s((((safe_sub_func_uint16_t_u_u(l_34, l_85)) | l_125) == l_90[2]), 48)) != 0x31L), 0x76211E33L));
            }
        }
        l_89 = (safe_mod_func_uint8_t_u_u(l_33, 251UL));
    }
    else
    { 
        const uint32_t l_144[1] = {18446744073709551610UL};
        int i;
        return l_144[0];
    }
    return l_6;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 40
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 44
   depth: 2, occurrence: 15
   depth: 3, occurrence: 10
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 98
XXX times a non-volatile is write: 38
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 51
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 7
   depth: 2, occurrence: 15
   depth: 3, occurrence: 25

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
XXX total OOB instances added: 0
********************* end of statistics **********************/

