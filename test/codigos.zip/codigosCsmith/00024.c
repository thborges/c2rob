/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00024.c -s 00024 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      24
 */

#include "csmith.h"


static long __undefined;






static int8_t  func_1(void);





static int8_t  func_1(void)
{ 
    int32_t l_2 = 6L;
    int32_t l_12 = 0xC8F0D071L;
    int32_t l_21 = 1L;
    int32_t l_27 = (-1L);
    int32_t l_33[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint8_t l_36 = 0UL;
    int i;
    for (l_2 = 25; (l_2 == 10); l_2--)
    { 
        int32_t l_5 = 5L;
        int32_t l_13 = 1L;
        int32_t l_18 = 0L;
        int32_t l_20[8] = {0x36BE856DL,6L,0x36BE856DL,0x36BE856DL,6L,0x36BE856DL,0x36BE856DL,6L};
        const uint16_t l_52 = 7UL;
        int64_t l_55 = 0x4BE5697A12B2FE07LL;
        int i;
        for (l_5 = 0; (l_5 == 24); l_5++)
        { 
            int64_t l_8[1];
            int32_t l_9[1];
            int32_t l_10 = 0xA97963BAL;
            int32_t l_14 = 0x184DCC80L;
            int32_t l_16 = 0xF5BFB66FL;
            int32_t l_22 = 1L;
            int32_t l_24 = (-1L);
            int32_t l_30[3];
            int i;
            for (i = 0; i < 1; i++)
                l_8[i] = 0xC62E08974B666A75LL;
            for (i = 0; i < 1; i++)
                l_9[i] = (-1L);
            for (i = 0; i < 3; i++)
                l_30[i] = 0x4C638299L;
            for (l_9[0] = 0; (l_9[0] >= 0); l_9[0] -= 1)
            { 
                int32_t l_11 = 0x0D461E3FL;
                int32_t l_15 = 0x5C2DD78FL;
                int32_t l_17 = 0x1AC3DC99L;
                int32_t l_19 = (-10L);
                int32_t l_23 = 1L;
                int32_t l_25 = 0xF355C0C8L;
                int32_t l_26 = (-1L);
                int32_t l_28 = 0xE3D97867L;
                int32_t l_29 = 0x8BBE26B5L;
                int32_t l_31 = 0xA9C79EBEL;
                int32_t l_32 = 0x6D9E96BBL;
                int32_t l_34 = 0xF57B17B4L;
                int32_t l_35[8] = {1L,0xB7A2E255L,0xB7A2E255L,1L,0xB7A2E255L,0xB7A2E255L,1L,0xB7A2E255L};
                int i;
                l_36++;
            }
            for (l_36 = 2; (l_36 <= 7); l_36 += 1)
            { 
                int i;
                l_18 &= ((1UL <= 0x6BA8L) && l_20[l_36]);
                l_20[l_36] = ((safe_add_func_int16_t_s_s((((safe_add_func_uint16_t_u_u(l_20[l_36], (-2L))) < l_36) && 0UL), 0x6B49L)) != l_27);
                l_21 = (safe_add_func_uint64_t_u_u(l_13, l_33[5]));
            }
            if ((safe_add_func_uint64_t_u_u(0x588DFEF28ED3351FLL, (-3L))))
            { 
                int64_t l_51 = 8L;
                l_16 |= ((safe_mod_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(l_51, l_9[0])), l_52)) == l_13);
            }
            else
            { 
                l_30[0] = (1UL == 1L);
            }
        }
        l_20[7] |= (safe_lshift_func_uint8_t_u_s((l_21 != 1L), 1));
        if (((l_55 == l_12) | l_2))
        { 
            for (l_36 = 0; l_36 < 8; l_36 += 1)
            {
                l_20[l_36] = 5L;
            }
        }
        else
        { 
            uint16_t l_56 = 0x4666L;
            l_5 |= l_33[5];
            return l_56;
        }
    }
    return l_21;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 31
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 3
   depth: 2, occurrence: 6
   depth: 3, occurrence: 6

XXX percentage a fresh-made variable is used: 36.9
XXX percentage an existing variable is used: 63.1
XXX total OOB instances added: 0
********************* end of statistics **********************/

