/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00046.c -s 00046 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      46
 */

#include "csmith.h"


static long __undefined;


struct S1 {
   int32_t  f0;
   int32_t  f1;
   uint32_t  f2;
   int16_t  f3;
   int8_t  f4;
   uint32_t  f5;
};





static uint64_t  func_1(void);





static uint64_t  func_1(void)
{ 
    struct S1 l_2[7] = {{-10L,0xA329EF4AL,0x426A7609L,1L,1L,4294967295UL},{0x4F934F54L,0L,0UL,0xEB77L,0x78L,0xA8F90A3CL},{-10L,0xA329EF4AL,0x426A7609L,1L,1L,4294967295UL},{-10L,0xA329EF4AL,0x426A7609L,1L,1L,4294967295UL},{0x4F934F54L,0L,0UL,0xEB77L,0x78L,0xA8F90A3CL},{-10L,0xA329EF4AL,0x426A7609L,1L,1L,4294967295UL},{-10L,0xA329EF4AL,0x426A7609L,1L,1L,4294967295UL}};
    int32_t l_3 = 1L;
    int8_t l_9 = (-1L);
    int16_t l_51 = (-1L);
    int i;
    for (l_3 = 0; (l_3 <= 6); l_3 += 1)
    { 
        int64_t l_8[2];
        uint32_t l_10 = 1UL;
        int32_t l_11[1];
        int i;
        for (i = 0; i < 2; i++)
            l_8[i] = (-1L);
        for (i = 0; i < 1; i++)
            l_11[i] = 1L;
        l_11[0] &= (((safe_div_func_uint32_t_u_u((safe_mul_func_uint64_t_u_u(((l_3 > 0xFFL) <= l_8[0]), l_9)), 0x6FD8C658L)) || l_10) ^ l_3);
        for (l_9 = 4; (l_9 >= 2); l_9 -= 1)
        { 
            int i;
            l_2[l_3] = l_2[l_9];
            l_11[0] = (safe_mul_func_uint64_t_u_u(0x3FAA058A13C444C9LL, l_3));
            for (l_10 = 0; (l_10 <= 0); l_10 += 1)
            { 
                struct S1 l_14 = {0x4BAE9140L,-9L,18446744073709551613UL,1L,0L,4294967295UL};
                int i;
                l_14 = l_2[1];
                l_11[l_10] = (safe_add_func_int8_t_s_s(((((safe_div_func_int64_t_s_s(l_11[l_10], 0xDDA78404D0838303LL)) != 0x9BDDL) & l_11[l_10]) == l_11[l_10]), l_11[l_10]));
            }
        }
    }
    if ((safe_mul_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((((safe_lshift_func_int32_t_s_s(l_3, 1)) == 4294967295UL) && l_3) >= l_9), l_3)), 0xD1BAL)))
    { 
        uint64_t l_27 = 4UL;
        if ((safe_mul_func_uint64_t_u_u((l_3 > l_3), l_27)))
        { 
            int16_t l_28 = (-1L);
            int64_t l_29 = 0x6E9900F1D91A4AC1LL;
            struct S1 l_30 = {0x60729490L,0x9496125BL,0x6FFBA242L,0x39A3L,-1L,4294967289UL};
            int32_t l_37[4] = {0x2392579BL,0x2392579BL,0x2392579BL,0x2392579BL};
            int i;
            l_29 ^= l_28;
            l_30 = l_2[3];
            for (l_29 = 2; (l_29 <= 6); l_29 += 1)
            { 
                uint8_t l_31 = 0xCBL;
                return l_31;
            }
            for (l_27 = 0; (l_27 <= 6); l_27 += 1)
            { 
                uint16_t l_36 = 65535UL;
                l_37[3] &= ((safe_div_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u((l_36 & 65533UL), 12)), 5UL)) || 0xCA02L);
                return l_36;
            }
        }
        else
        { 
            uint8_t l_40 = 3UL;
            for (l_9 = (-28); (l_9 >= (-22)); l_9++)
            { 
                l_40++;
                l_3 |= (l_27 | l_27);
            }
            if ((safe_lshift_func_int64_t_s_u(((safe_rshift_func_int32_t_s_u(l_9, 24)) | l_40), 23)))
            { 
                return l_40;
            }
            else
            { 
                uint8_t l_47 = 0UL;
                l_47 |= (1L | l_40);
            }
        }
    }
    else
    { 
        int64_t l_52[8];
        int i;
        for (i = 0; i < 8; i++)
            l_52[i] = 8L;
        for (l_3 = 0; (l_3 >= (-8)); l_3 = safe_sub_func_int64_t_s_s(l_3, 4))
        { 
            uint8_t l_50[5] = {0xECL,0xECL,0xECL,0xECL,0xECL};
            int i;
            for (l_9 = 6; (l_9 >= 0); l_9 -= 1)
            { 
                int32_t l_53 = 0x4E934167L;
                l_53 = (((0UL && l_50[4]) > l_51) || l_52[5]);
            }
        }
    }
    return l_3;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 21
   depth: 2, occurrence: 11
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 42
XXX times a non-volatile is write: 20
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 10
   depth: 3, occurrence: 10

XXX percentage a fresh-made variable is used: 43.9
XXX percentage an existing variable is used: 56.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

