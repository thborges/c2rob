/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00020.c -s 00020 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      20
 */

#include "csmith.h"


static long __undefined;






static uint16_t  func_1(void);





static uint16_t  func_1(void)
{ 
    int32_t l_2 = (-1L);
    int16_t l_15 = 0x6810L;
    int16_t l_27 = 0xE91CL;
    int32_t l_54 = 0x5104F36CL;
    int32_t l_55 = 0x97E6E185L;
    int32_t l_56 = 0xD735F31AL;
    int32_t l_64 = 0xD1B8438CL;
    int32_t l_66[7];
    int i;
    for (i = 0; i < 7; i++)
        l_66[i] = 7L;
    if (l_2)
    { 
        uint8_t l_5 = 253UL;
        int32_t l_26[1];
        int i;
        for (i = 0; i < 1; i++)
            l_26[i] = 0xEF3B0639L;
        if ((safe_mul_func_uint64_t_u_u(l_5, 0L)))
        { 
            uint64_t l_14 = 18446744073709551607UL;
            int32_t l_30[8];
            int i;
            for (i = 0; i < 8; i++)
                l_30[i] = 0L;
            l_2 = (((safe_rshift_func_int8_t_s_s((safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u((l_2 | l_5), 1L)) != l_2), l_2)), l_14)), 3)) >= 0L) >= l_5);
            l_2 = l_15;
            for (l_14 = (-18); (l_14 >= 14); l_14 = safe_add_func_uint64_t_u_u(l_14, 6))
            { 
                int16_t l_21 = 0xB43DL;
                int32_t l_22[9] = {0L,0x1FA4C821L,0L,0L,0x1FA4C821L,0L,0L,0x1FA4C821L,0L};
                int i;
                l_22[5] ^= ((safe_mul_func_int16_t_s_s((((~l_21) || 0x7FL) > 0x9EE491BA6B42BE19LL), l_15)) ^ 0x653BL);
                l_26[0] = (safe_unary_minus_func_uint16_t_u((safe_lshift_func_uint32_t_u_u(l_5, 15))));
                l_22[4] = l_27;
            }
            l_30[4] = (((safe_rshift_func_int64_t_s_s(l_26[0], l_26[0])) > l_26[0]) != l_5);
        }
        else
        { 
            uint32_t l_35 = 4UL;
            int32_t l_46 = 0x45597EEDL;
            for (l_2 = 0; (l_2 <= (-30)); l_2 = safe_sub_func_int8_t_s_s(l_2, 5))
            { 
                const uint32_t l_44 = 1UL;
                int32_t l_45 = (-1L);
                l_35 |= (safe_sub_func_int16_t_s_s(0x5DD2L, l_26[0]));
                l_26[0] = (safe_div_func_uint8_t_u_u(l_26[0], l_2));
                l_46 = (safe_lshift_func_int32_t_s_u((((safe_add_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u((l_44 == l_35), l_45)), l_44)) ^ l_45) > l_26[0]), l_35));
            }
            for (l_5 = 0; (l_5 <= 0); l_5 += 1)
            { 
                uint32_t l_47 = 0xA061FA46L;
                int i;
                l_47 |= (l_26[l_5] || l_26[l_5]);
                return l_26[l_5];
            }
        }
        l_26[0] = (safe_add_func_int8_t_s_s((l_2 != l_15), l_5));
        l_2 &= (-3L);
        l_2 = 0x6C0953B2L;
    }
    else
    { 
        int32_t l_50[7] = {(-1L),0xB76FEF6FL,(-1L),(-1L),0xB76FEF6FL,(-1L),(-1L)};
        int i;
        for (l_2 = 2; (l_2 <= 6); l_2 += 1)
        { 
            int32_t l_59 = 0x0CE5FA5BL;
            int32_t l_60 = 0x26B3FA45L;
            int32_t l_61 = (-1L);
            int32_t l_62[5] = {8L,8L,8L,8L,8L};
            uint32_t l_67 = 0xD7EEACC2L;
            int i;
            if ((safe_lshift_func_int64_t_s_s((0x26L & l_50[l_2]), l_50[l_2])))
            { 
                uint32_t l_53 = 0xCBABA27FL;
                int32_t l_57 = 0x882D7787L;
                int32_t l_58[6] = {0L,0L,0L,0L,0L,0L};
                int32_t l_63 = 5L;
                int16_t l_65 = 0L;
                int i;
                l_50[l_2] = (l_53 >= 18446744073709551612UL);
                l_54 = (((l_50[l_2] > l_50[4]) || l_15) || 0xDA7D8E2DC6606A86LL);
                l_67--;
                l_59 = (safe_mod_func_uint32_t_u_u((safe_rshift_func_int64_t_s_u(((safe_mul_func_int32_t_s_s((safe_div_func_int8_t_s_s((safe_lshift_func_uint32_t_u_s(1UL, 22)), l_60)), l_2)) >= 0x577EL), l_61)), l_67));
            }
            else
            { 
                const int32_t l_86 = 0xAD64B6C7L;
                int32_t l_87 = 0L;
                l_87 ^= (safe_lshift_func_int64_t_s_s((safe_rshift_func_uint64_t_u_u(((safe_lshift_func_uint8_t_u_u(0x67L, l_61)) ^ l_86), 17)), l_50[0]));
            }
            for (l_59 = 4; (l_59 >= 0); l_59 -= 1)
            { 
                int i;
                l_50[l_2] = (((((safe_mod_func_int32_t_s_s(((safe_mul_func_uint16_t_u_u((safe_mul_func_int32_t_s_s(l_50[l_2], l_62[l_59])), l_50[1])) >= l_27), l_50[l_2])) | l_50[l_2]) | 0UL) != 1UL) > l_27);
                l_50[l_2] = l_50[2];
            }
        }
        for (l_27 = 1; (l_27 <= 6); l_27 += 1)
        { 
            int i;
            return l_66[l_27];
        }
    }
    l_66[4] &= ((l_2 || l_15) || l_15);
    if ((!0x8026BCB33D27CF1ALL))
    { 
        int8_t l_101[3];
        int i;
        for (i = 0; i < 3; i++)
            l_101[i] = 0x18L;
        for (l_54 = (-5); (l_54 == (-25)); l_54 = safe_sub_func_int8_t_s_s(l_54, 6))
        { 
            int16_t l_102 = 0L;
            for (l_64 = 16; (l_64 < 2); l_64--)
            { 
                int64_t l_103 = 2L;
                l_103 &= ((safe_mod_func_int64_t_s_s(((((((0xA549L && (-1L)) <= l_56) != l_101[1]) && 18446744073709551614UL) | (-1L)) < l_102), l_27)) || 6UL);
                l_2 = ((safe_unary_minus_func_uint32_t_u((safe_mod_func_uint16_t_u_u((((safe_add_func_int64_t_s_s(l_55, l_56)) != l_103) < 0x2DD077F0L), l_101[1])))) > l_103);
            }
        }
    }
    else
    { 
        int32_t l_109 = 0x0811D275L;
        uint32_t l_114[9] = {3UL,3UL,3UL,3UL,3UL,3UL,3UL,3UL,3UL};
        int32_t l_115 = 0x988067FCL;
        int8_t l_125 = 0x4FL;
        int i;
        l_109 |= 0xB2A787E5L;
        l_115 |= ((safe_mul_func_uint16_t_u_u(((((((((safe_rshift_func_uint8_t_u_u(0UL, l_66[2])) <= l_64) < l_15) != l_15) && 1UL) | 0x2E5DL) & l_27) && l_2), l_109)) && l_114[3]);
        for (l_15 = 8; (l_15 >= 2); l_15 -= 1)
        { 
            uint16_t l_120 = 0x7078L;
            l_120 = (safe_mod_func_int32_t_s_s((((safe_sub_func_int64_t_s_s((l_56 ^ 9L), (-2L))) & l_114[3]) > l_56), l_54));
            l_2 = l_55;
        }
        if ((safe_div_func_uint16_t_u_u(l_114[3], l_114[8])))
        { 
            for (l_27 = 5; (l_27 >= 0); l_27 -= 1)
            { 
                int i;
                return l_114[(l_27 + 3)];
            }
        }
        else
        { 
            int32_t l_123 = 0L;
            int32_t l_124[5] = {1L,1L,1L,1L,1L};
            int32_t l_126[9] = {1L,0L,1L,0L,1L,0L,1L,0L,1L};
            int i;
            l_126[7] &= ((((l_123 & l_124[2]) >= (-1L)) || l_125) >= l_55);
            l_64 ^= 3L;
            l_109 = ((((safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s(l_124[3], 2)), 4)) > (-9L)) && l_27) <= 1UL);
            return l_126[7];
        }
    }
    return l_64;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 46
   depth: 2, occurrence: 17
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 9, occurrence: 3
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 101
XXX times a non-volatile is write: 40
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 50
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 11
   depth: 2, occurrence: 17
   depth: 3, occurrence: 18

XXX percentage a fresh-made variable is used: 25.6
XXX percentage an existing variable is used: 74.4
XXX total OOB instances added: 0
********************* end of statistics **********************/

