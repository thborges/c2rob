/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00007.c -s 00007 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      7
 */

#include "csmith.h"


static long __undefined;






static uint32_t  func_1(void);





static uint32_t  func_1(void)
{ 
    uint8_t l_2[5];
    int32_t l_3 = 1L;
    int32_t l_8 = 9L;
    uint8_t l_35 = 5UL;
    int32_t l_38 = 0x0E9EE194L;
    uint32_t l_40[10] = {0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L,0xF50E4B46L};
    int8_t l_67 = 0xF2L;
    int32_t l_79[8] = {0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L,0xC2F3D1A1L};
    uint32_t l_102 = 4294967293UL;
    uint32_t l_140 = 4294967295UL;
    int32_t l_147 = 0x0A70E4C8L;
    uint64_t l_150[6] = {5UL,5UL,5UL,5UL,5UL,5UL};
    int8_t l_171 = 0xABL;
    int i;
    for (i = 0; i < 5; i++)
        l_2[i] = 0UL;
    for (l_3 = 4; (l_3 >= 0); l_3 -= 1)
    { 
        int32_t l_7 = 0L;
        uint64_t l_16 = 0x11AA84CBED562B99LL;
        int i;
        l_7 &= ((+(safe_add_func_int16_t_s_s(l_2[l_3], l_2[l_3]))) < l_2[l_3]);
        l_8 = l_2[l_3];
        l_7 = ((!l_8) || l_2[l_3]);
        if ((safe_sub_func_uint8_t_u_u(l_7, l_7)))
        { 
            int32_t l_14[9] = {5L,5L,5L,5L,5L,5L,5L,5L,5L};
            int32_t l_22 = 0x2452A2C7L;
            int i;
            l_7 = (safe_lshift_func_int8_t_s_s((l_7 ^ l_2[l_3]), l_14[4]));
            if (((+(l_16 == l_3)) != l_8))
            { 
                int32_t l_21 = 1L;
                l_8 = (l_14[3] && (-9L));
                l_22 &= (safe_mod_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s(((l_14[4] > l_21) == 65527UL), l_8)), l_14[4]));
                l_7 = (safe_mod_func_int16_t_s_s(0x0598L, 0x7A30L));
                l_21 ^= l_16;
            }
            else
            { 
                int32_t l_25 = (-1L);
                l_14[4] = (l_25 && l_7);
            }
        }
        else
        { 
            l_7 = (safe_sub_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s((safe_div_func_uint8_t_u_u(0UL, 0x0FL)), 5)), 8UL));
        }
    }
    for (l_3 = 0; (l_3 <= 4); l_3 += 1)
    { 
        int64_t l_36 = 0x45C66B31915E3087LL;
        int32_t l_44[2];
        int8_t l_69 = 6L;
        int16_t l_93 = (-7L);
        int i;
        for (i = 0; i < 2; i++)
            l_44[i] = 1L;
        for (l_8 = 4; (l_8 >= 0); l_8 -= 1)
        { 
            int32_t l_32[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            for (l_32[3] = 4; (l_32[3] >= 0); l_32[3] -= 1)
            { 
                int i;
                return l_2[l_8];
            }
            if (((((safe_rshift_func_uint8_t_u_s((l_2[l_8] <= l_2[l_8]), 2)) <= l_35) && 1UL) | (-1L)))
            { 
                uint64_t l_37[7] = {0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL,0x51CC0D6813F8C547LL};
                int i;
                l_38 = (l_36 > l_37[0]);
            }
            else
            { 
                uint32_t l_39 = 0x5E691445L;
                int32_t l_41 = 0x67F3E8E0L;
                l_38 = ((l_32[0] <= l_39) <= 0x5BL);
                l_38 = (l_3 || l_32[2]);
                l_41 = l_40[8];
                l_44[0] &= ((safe_add_func_uint64_t_u_u(l_36, l_36)) >= 0x60L);
            }
        }
        l_44[0] ^= (safe_div_func_int64_t_s_s((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(l_2[l_3], l_2[0])), l_2[0])), 0xC80C5262L)), l_40[8]));
        for (l_36 = 0; (l_36 <= 4); l_36 += 1)
        { 
            uint8_t l_68 = 0UL;
            l_44[1] = (safe_mul_func_int16_t_s_s(((((((safe_mod_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(((safe_rshift_func_int64_t_s_s((0xDB22284F583EF4C8LL | 0x3D9AAD11CF5132FCLL), 29)) & l_44[1]), l_67)), l_67)), 0x0B13CFF85525C537LL)), l_67)), l_40[8])) <= 0x29DC0630FC3BC345LL) | l_35) & l_2[l_3]) < l_68) > 2L), (-1L)));
            l_38 |= l_44[0];
        }
        l_44[0] = l_69;
        for (l_38 = 0; (l_38 <= 4); l_38 += 1)
        { 
            int32_t l_78 = 0x86B8A71AL;
            int32_t l_80 = 0xCDA06E20L;
            int32_t l_81 = 0xB49DA01FL;
            l_81 &= (safe_sub_func_int32_t_s_s((((((((safe_rshift_func_int32_t_s_s(((((safe_rshift_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u((l_38 >= l_2[l_3]), l_78)) <= l_79[1]), 12)) >= l_2[1]) & l_8) != l_80), l_2[l_3])) >= 0x9A370827L) < l_80) == l_40[5]) <= 0L) < 0x53E4L) >= (-1L)), l_40[8]));
            for (l_81 = 4; (l_81 >= 0); l_81 -= 1)
            { 
                int i;
                l_79[(l_3 + 3)] = ((~(safe_sub_func_uint32_t_u_u(0x3C057171L, l_80))) > (-4L));
                l_44[1] |= (safe_rshift_func_int64_t_s_u((-1L), 21));
                l_8 &= ((safe_mod_func_int64_t_s_s((+((l_79[(l_3 + 3)] & l_80) ^ (-1L))), l_44[0])) >= l_80);
            }
            l_44[0] = (((((safe_div_func_uint32_t_u_u((!(((l_40[8] == l_2[l_3]) == l_78) <= l_2[0])), l_79[0])) && 0xBAL) && l_40[8]) & l_81) <= l_93);
        }
    }
    for (l_67 = 4; (l_67 >= 1); l_67 -= 1)
    { 
        uint8_t l_103 = 0x54L;
        int32_t l_107 = 0x135E92A0L;
        for (l_38 = 0; (l_38 <= 4); l_38 += 1)
        { 
            uint32_t l_104[1];
            int32_t l_115[4] = {0L,0L,0L,0L};
            int i;
            for (i = 0; i < 1; i++)
                l_104[i] = 18446744073709551609UL;
            l_8 = (safe_div_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(0xB5DFL, 0x643AL)), 1)), 0x20L)) & l_79[7]), l_102));
            l_104[0] = l_103;
            l_3 = (((((safe_sub_func_uint16_t_u_u((0UL >= l_104[0]), l_104[0])) >= l_38) >= 0x77144E55L) || l_104[0]) | l_107);
            for (l_102 = 0; (l_102 <= 4); l_102 += 1)
            { 
                uint8_t l_114 = 0x75L;
                l_115[2] = ((safe_add_func_int16_t_s_s(((safe_lshift_func_uint64_t_u_s(((safe_sub_func_int16_t_s_s(((l_114 ^ 18446744073709551615UL) >= 8L), l_104[0])) >= l_103), l_104[0])) >= l_104[0]), 0xC7AFL)) < 0xD02F7E15FDC67391LL);
            }
        }
    }
    for (l_3 = 6; (l_3 >= 1); l_3 -= 1)
    { 
        uint32_t l_118 = 0xF1F9D108L;
        int32_t l_136[7] = {0x1E1293A1L,0x1E1293A1L,0x1E1293A1L,0x1E1293A1L,0x1E1293A1L,0x1E1293A1L,0x1E1293A1L};
        uint8_t l_142 = 2UL;
        int16_t l_169[3];
        int8_t l_170 = (-3L);
        int32_t l_172 = 0L;
        int8_t l_173 = (-1L);
        uint16_t l_174 = 0x9FBBL;
        int i;
        for (i = 0; i < 3; i++)
            l_169[i] = 6L;
        for (l_38 = 7; (l_38 >= 0); l_38 -= 1)
        { 
            int32_t l_119[6] = {0x156C3613L,0x156C3613L,0x156C3613L,0x156C3613L,0x156C3613L,0x156C3613L};
            int i;
            l_119[5] &= (safe_add_func_int16_t_s_s(l_79[l_3], l_118));
            return l_79[l_3];
        }
        if ((safe_div_func_uint8_t_u_u(l_79[l_3], l_79[l_3])))
        { 
            uint32_t l_126 = 0xB7E93FE2L;
            int32_t l_141[10] = {0x913A6832L,0xD02E7AF9L,0xD02E7AF9L,0x913A6832L,0x285BD8C4L,0x913A6832L,0xD02E7AF9L,0xD02E7AF9L,0x913A6832L,0x285BD8C4L};
            int i;
            if (((safe_add_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((l_126 > l_118), l_38)), 0x0D2C52FFL)) | l_126))
            { 
                l_8 &= (safe_add_func_int64_t_s_s((-1L), l_79[l_3]));
                return l_102;
            }
            else
            { 
                int16_t l_135[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_135[i] = 0L;
                l_136[5] &= ((((safe_sub_func_int32_t_s_s((safe_lshift_func_int32_t_s_u((safe_div_func_int32_t_s_s(((l_79[l_3] || l_2[4]) ^ 0x5F4EL), l_135[0])), l_135[0])), l_126)) ^ l_79[l_3]) >= l_67) >= l_79[l_3]);
                l_79[l_3] &= 0xF77099D3L;
                l_8 = ((+(safe_rshift_func_uint16_t_u_u(l_126, l_140))) < 4294967291UL);
                l_136[5] = (l_126 & 0xD0L);
            }
            l_142++;
            l_147 = (safe_sub_func_int64_t_s_s(0x768D1CA076940D3DLL, l_141[1]));
            for (l_102 = 0; (l_102 >= 12); l_102 = safe_add_func_int16_t_s_s(l_102, 1))
            { 
                l_79[3] = (0x9A790D782557159CLL | 0xEA98C39ED3BE867FLL);
                l_150[0] = l_79[l_3];
                l_8 ^= l_141[1];
            }
        }
        else
        { 
            uint32_t l_151 = 0x1A2BA53DL;
            int32_t l_157 = (-3L);
            const int32_t l_164 = 5L;
            l_151++;
            if ((255UL > l_151))
            { 
                const int64_t l_154 = 0xA0ABA9B552DC146CLL;
                int32_t l_158 = 0x70683A55L;
                l_79[1] = ((((l_151 < l_79[l_3]) < l_118) < l_154) & 0x29961D603A4C91E0LL);
                l_157 &= (safe_sub_func_uint32_t_u_u(l_151, 0xE00D0B8EL));
                l_158 = (l_136[5] <= l_118);
                return l_151;
            }
            else
            { 
                uint8_t l_159 = 4UL;
                l_159 = 1L;
                l_157 |= 0x35014F3CL;
                l_79[l_3] &= (safe_rshift_func_int64_t_s_s((safe_mul_func_uint32_t_u_u(l_164, l_136[5])), l_151));
            }
            for (l_8 = 7; (l_8 >= 0); l_8 -= 1)
            { 
                int i;
                l_79[l_8] = (safe_rshift_func_int64_t_s_u(((safe_div_func_int32_t_s_s(1L, l_79[l_8])) != l_164), l_79[l_8]));
            }
        }
        l_174--;
        return l_40[8];
    }
    return l_38;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 51
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 68
   depth: 2, occurrence: 31
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 5
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 3
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 142
XXX times a non-volatile is write: 62
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 74
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 14
   depth: 2, occurrence: 23
   depth: 3, occurrence: 32

XXX percentage a fresh-made variable is used: 24.5
XXX percentage an existing variable is used: 75.5
XXX total OOB instances added: 0
********************* end of statistics **********************/

