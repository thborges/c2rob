/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00026.c -s 00026 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      26
 */

#include "csmith.h"


static long __undefined;






static uint32_t  func_1(void);





static uint32_t  func_1(void)
{ 
    int16_t l_9 = 1L;
    uint32_t l_10 = 0x579253A3L;
    uint64_t l_11[7];
    int16_t l_33 = (-1L);
    int32_t l_53 = 0x7B790EB5L;
    int32_t l_82 = 0x2A635BD1L;
    int32_t l_95 = 8L;
    uint64_t l_106 = 1UL;
    int32_t l_107 = 0x8CC5E00EL;
    int16_t l_115 = 0x0A06L;
    uint8_t l_127 = 0x26L;
    int32_t l_140 = 0L;
    uint8_t l_146 = 0xC8L;
    int32_t l_161 = 0xB782AFEDL;
    uint32_t l_162[9];
    int8_t l_178 = 0L;
    int32_t l_195 = (-1L);
    int i;
    for (i = 0; i < 7; i++)
        l_11[i] = 0UL;
    for (i = 0; i < 9; i++)
        l_162[i] = 3UL;
    if ((safe_rshift_func_int64_t_s_s(((safe_div_func_int16_t_s_s((safe_unary_minus_func_int32_t_s((((safe_mul_func_int64_t_s_s(((l_9 != l_9) ^ l_9), 18446744073709551608UL)) >= l_9) && 18446744073709551610UL))), l_10)) || l_10), l_11[4])))
    { 
        uint32_t l_12 = 0x81479B69L;
        l_12--;
    }
    else
    { 
        int32_t l_21 = 0xEC7E4343L;
        int32_t l_22[4];
        int32_t l_27[5];
        uint64_t l_40[2];
        const int64_t l_48 = (-4L);
        int32_t l_50 = 0x93B76F05L;
        int16_t l_63 = 0x42ACL;
        int32_t l_65 = 1L;
        uint64_t l_75[6];
        int i;
        for (i = 0; i < 4; i++)
            l_22[i] = (-3L);
        for (i = 0; i < 5; i++)
            l_27[i] = (-3L);
        for (i = 0; i < 2; i++)
            l_40[i] = 0x2BBA2D3C5EBB4EE0LL;
        for (i = 0; i < 6; i++)
            l_75[i] = 18446744073709551609UL;
        l_22[0] = ((safe_add_func_int8_t_s_s((((safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((l_9 && l_21), 2)), l_9)) & l_9) != l_21), l_21)) < l_9);
        for (l_21 = (-26); (l_21 > (-30)); l_21--)
        { 
            uint32_t l_28 = 0x24B6749EL;
            l_28 |= ((safe_mul_func_uint16_t_u_u((l_21 | l_27[1]), l_10)) && l_10);
        }
        if (((safe_div_func_uint64_t_u_u(((safe_rshift_func_uint64_t_u_s(l_27[4], l_33)) < l_9), 0x38770CE404D46446LL)) < l_22[0]))
        { 
            uint64_t l_37 = 0x47B6C411E69D0863LL;
            l_22[0] = (safe_lshift_func_uint64_t_u_u(l_9, l_21));
            l_37 = (!l_11[2]);
            if (((safe_rshift_func_uint64_t_u_u(((l_40[0] == l_9) <= 0x19B1L), 12)) != 0x59C2D16CL))
            { 
                uint16_t l_47 = 65533UL;
                int32_t l_49 = 8L;
                l_22[0] ^= (safe_mod_func_uint16_t_u_u(((safe_add_func_int16_t_s_s(l_40[1], 0x97D6L)) <= l_10), l_10));
                l_49 = ((safe_rshift_func_uint32_t_u_u(l_40[0], l_47)) ^ l_48);
                l_50 = l_37;
                l_22[0] = l_10;
            }
            else
            { 
                l_53 |= (safe_div_func_uint16_t_u_u((((0UL != l_21) | l_10) && l_21), 0x8998L));
            }
        }
        else
        { 
            uint32_t l_58 = 0xE6D7BFF0L;
            if ((safe_div_func_uint8_t_u_u((((safe_mod_func_uint16_t_u_u((9L > l_27[3]), 65535UL)) < l_58) <= l_40[0]), l_58)))
            { 
                uint32_t l_64 = 2UL;
                l_22[0] &= ((safe_div_func_int8_t_s_s((safe_mul_func_uint32_t_u_u((l_27[1] & l_48), 8UL)), 0x0FL)) >= 0x7A7CF8314CD5900ALL);
                l_64 = l_63;
                l_65 |= (l_22[0] <= 0UL);
            }
            else
            { 
                uint32_t l_74 = 0UL;
                int32_t l_76 = 0x48679C02L;
                l_76 = (((safe_add_func_uint64_t_u_u((safe_rshift_func_int64_t_s_s(((safe_mod_func_uint8_t_u_u((safe_mul_func_uint32_t_u_u(((l_40[0] != l_74) >= l_22[0]), l_10)), l_75[3])) > 0x4C01L), l_75[0])), l_50)) >= l_11[4]) && 0x5150L);
            }
        }
    }
    for (l_53 = 20; (l_53 <= 9); l_53 = safe_sub_func_uint16_t_u_u(l_53, 3))
    { 
        uint64_t l_80 = 9UL;
        int32_t l_92 = (-1L);
        int32_t l_97[5];
        int i;
        for (i = 0; i < 5; i++)
            l_97[i] = (-6L);
        for (l_10 = 2; (l_10 <= 6); l_10 += 1)
        { 
            int32_t l_79 = 0x55BF9BF4L;
            int i;
            l_79 = l_11[l_10];
            return l_11[l_10];
        }
        for (l_9 = 6; (l_9 >= 2); l_9 -= 1)
        { 
            int8_t l_81[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            uint8_t l_96 = 1UL;
            int i;
            l_82 ^= ((((((-1L) & l_9) <= l_80) != l_81[3]) || 0L) || 1UL);
            if (l_81[6])
            { 
                uint8_t l_83 = 0xB4L;
                l_83 = l_81[1];
                l_82 = ((+((safe_mul_func_int32_t_s_s((((0x9973L <= (-1L)) <= l_80) > l_80), (-1L))) > (-5L))) <= l_83);
                l_82 = (l_81[3] >= l_11[6]);
            }
            else
            { 
                int32_t l_87 = 0x385A40E5L;
                l_87 &= l_80;
                l_92 = (((((safe_mul_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((((0xB4L & l_80) <= 0x2EA524B1L) == l_10), 1)), 0x10L)) >= l_80) < 0L) | l_81[5]) && l_80);
                l_87 = 0L;
                return l_33;
            }
            l_92 |= (safe_lshift_func_int16_t_s_s(l_82, 9));
            l_96 = (l_11[4] != l_95);
        }
        l_97[2] |= l_92;
        for (l_10 = (-25); (l_10 >= 35); l_10 = safe_add_func_uint32_t_u_u(l_10, 4))
        { 
            uint8_t l_105 = 250UL;
            if (((safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((+l_105), l_106)), l_105)) ^ 0x49D7A73C59DB3CA6LL))
            { 
                l_82 = l_97[2];
                l_82 = (0x6AL & l_11[5]);
                l_107 ^= (l_105 == l_105);
                l_82 = l_106;
            }
            else
            { 
                uint16_t l_108[7] = {0x6AA8L,0x6AA8L,0x6AA8L,0x6AA8L,0x6AA8L,0x6AA8L,0x6AA8L};
                int i;
                l_97[2] = l_108[2];
                l_97[4] = l_82;
                return l_108[3];
            }
            l_92 |= ((safe_rshift_func_int16_t_s_s((safe_mul_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u(l_107, 0x940FB084A9EC0CD8LL)) && l_115) >= l_105), l_97[1])), 5)) < 0x67006BDA4C5B4E2CLL);
            l_82 = (safe_div_func_uint8_t_u_u(((safe_lshift_func_uint64_t_u_u(((safe_rshift_func_int16_t_s_s(((safe_lshift_func_int32_t_s_u(((!(safe_mod_func_uint64_t_u_u((l_97[1] >= l_105), l_80))) <= l_127), l_105)) & 0L), 10)) == l_105), 24)) != (-8L)), l_92));
        }
    }
    if ((l_11[6] == l_11[4]))
    { 
        const int16_t l_129 = 0x5B2AL;
        int32_t l_133 = 0x29B62C09L;
        uint32_t l_134 = 1UL;
        for (l_95 = 6; (l_95 >= 0); l_95 -= 1)
        { 
            int16_t l_128[6] = {0x005AL,1L,1L,0x005AL,1L,1L};
            int i;
            l_128[0] = ((0UL == l_11[l_95]) | l_106);
        }
        l_82 = (((((0x66L && l_129) >= 0xEDL) != l_33) ^ 0L) >= 1UL);
        for (l_127 = (-10); (l_127 == 45); l_127 = safe_add_func_uint32_t_u_u(l_127, 2))
        { 
            int16_t l_132 = 1L;
            l_132 = (0x4C4DL <= 0x8532L);
            l_133 = (l_129 | l_129);
            l_53 = (((0xFB2DL >= 65535UL) <= l_133) > l_133);
        }
        return l_134;
    }
    else
    { 
        uint16_t l_135[4];
        int32_t l_149 = 0x1F78AD59L;
        int i;
        for (i = 0; i < 4; i++)
            l_135[i] = 0x63ADL;
        l_135[0] = 0L;
        for (l_82 = 2; (l_82 >= (-5)); l_82 = safe_sub_func_int32_t_s_s(l_82, 2))
        { 
            uint64_t l_147 = 0xC93EDB1A9972B2CCLL;
            int32_t l_148 = 0x376D112AL;
            int32_t l_154[5];
            int i;
            for (i = 0; i < 5; i++)
                l_154[i] = 0xB91D3D6DL;
            for (l_53 = 0; (l_53 == (-1)); l_53 = safe_sub_func_uint16_t_u_u(l_53, 8))
            { 
                int16_t l_145 = 0x0FD9L;
                l_140 &= (18446744073709551614UL & l_135[2]);
                l_148 &= ((safe_mul_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u((l_145 || 0x0E5FF1E6L), l_146)) != 1L) < 0x4F4D21A526C73BF6LL), l_147)) != l_115);
                l_148 = (0UL > 0x56F6DE51L);
                l_149 = l_11[4];
            }
            for (l_95 = 3; (l_95 >= 0); l_95 -= 1)
            { 
                int i;
                l_148 = l_135[l_95];
                l_154[3] |= (safe_add_func_int32_t_s_s((safe_lshift_func_uint64_t_u_s(((0x792C5CF5L && 0x0BB33706L) == 0x3C81L), 17)), l_148));
            }
        }
        l_82 = (((((safe_div_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(0x8F90L, l_106)), l_135[0])) >= l_115) < l_135[1]) > 0x5156C434L) < l_9);
        l_149 ^= (safe_add_func_uint16_t_u_u(0xCEA6L, l_115));
    }
    for (l_53 = 2; (l_53 <= 6); l_53 += 1)
    { 
        int32_t l_169 = 0xB32F8ACAL;
        int i;
        l_162[2]++;
        for (l_161 = 0; (l_161 <= 6); l_161 += 1)
        { 
            uint32_t l_172 = 0x55504D00L;
            for (l_107 = 7; (l_107 >= 0); l_107 -= 1)
            { 
                int i;
                l_82 = ((l_11[l_161] ^ 4UL) == 0x8A19F7B7L);
                l_140 = 0x7208DD12L;
                l_82 = (((safe_mul_func_uint8_t_u_u(((safe_rshift_func_int64_t_s_s(l_162[(l_161 + 1)], l_162[l_161])) <= l_169), 0xB2L)) <= l_162[l_161]) > 1L);
                l_169 = ((safe_add_func_int8_t_s_s((0xECC6D06614CE2B89LL ^ l_162[(l_161 + 1)]), l_127)) ^ l_169);
            }
            l_172--;
        }
        if ((l_11[l_53] || l_11[l_53]))
        { 
            int8_t l_180[2];
            int32_t l_183 = 7L;
            int i;
            for (i = 0; i < 2; i++)
                l_180[i] = 0xF6L;
            for (l_140 = 5; (l_140 >= 0); l_140 -= 1)
            { 
                int32_t l_175 = 0xA3A9A028L;
                int i;
                l_169 &= l_162[(l_140 + 2)];
                l_175 = 0x5BBA217EL;
            }
            if (l_11[l_53])
            { 
                uint64_t l_177 = 1UL;
                l_178 = (safe_unary_minus_func_int64_t_s(l_177));
                l_82 ^= (+l_177);
                l_180[0] ^= ((0xC3L < l_177) && l_115);
            }
            else
            { 
                l_140 |= (safe_mul_func_int32_t_s_s(1L, l_11[4]));
                l_183 ^= 2L;
                l_169 &= (safe_mod_func_uint8_t_u_u((safe_rshift_func_uint32_t_u_u((0x6BC24C8DL == l_11[l_53]), 2)), 0xC2L));
            }
            for (l_106 = 2; (l_106 <= 6); l_106 += 1)
            { 
                uint32_t l_188[8] = {0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL,0xB3CBE0EAL};
                int i;
                l_161 = 0L;
                l_169 ^= l_188[2];
            }
            l_183 |= (safe_mul_func_uint64_t_u_u(((safe_div_func_int32_t_s_s((safe_add_func_uint64_t_u_u(l_195, 3UL)), l_169)) ^ l_180[0]), l_10));
        }
        else
        { 
            int32_t l_196[3];
            int i;
            for (i = 0; i < 3; i++)
                l_196[i] = (-8L);
            for (l_161 = 4; (l_161 >= 1); l_161 -= 1)
            { 
                l_196[1] = l_127;
            }
        }
        if ((safe_div_func_int64_t_s_s(l_162[2], 0x23A43FDB6C3E7DB0LL)))
        { 
            uint32_t l_199[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
            int32_t l_200 = 0xA520F3B2L;
            int i;
            l_200 = l_199[5];
            l_82 = l_200;
            l_169 |= (((safe_sub_func_int32_t_s_s(l_11[l_53], l_199[5])) >= l_11[l_53]) >= l_11[1]);
            if ((l_169 < l_11[l_53]))
            { 
                return l_199[5];
            }
            else
            { 
                l_82 &= ((safe_div_func_int16_t_s_s(l_11[l_53], 0x55D4L)) == 0xF00DC9259771E923LL);
                l_200 = (0x74175C3EL && 3L);
            }
        }
        else
        { 
            uint8_t l_215 = 0x13L;
            int32_t l_217 = 0x7ED1BB12L;
            for (l_106 = 2; (l_106 <= 6); l_106 += 1)
            { 
                int32_t l_216 = 3L;
                int i;
                l_216 = ((safe_add_func_int64_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(((safe_add_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(l_162[(l_53 + 1)], (-5L))), l_215)) >= 0x4324DB4BE808619DLL), 7UL)), l_215)), 0xCD61C992B2AA7F5FLL)) > (-7L));
                return l_146;
            }
            for (l_195 = 6; (l_195 >= 0); l_195 -= 1)
            { 
                uint32_t l_222[8] = {4UL,0xD77FB83BL,4UL,0xD77FB83BL,4UL,0xD77FB83BL,4UL,0xD77FB83BL};
                int i;
                l_217 = 0x33EBA6D4L;
                l_222[3] &= (safe_mod_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((l_215 | 0xAD26139D5ECBE261LL), l_215)), 0x06L));
                l_169 = (((safe_rshift_func_int8_t_s_s((safe_div_func_uint64_t_u_u(0xA00E7A821EC393FFLL, 9UL)), l_217)) != 2UL) & l_11[l_53]);
            }
            for (l_115 = 0; (l_115 <= 6); l_115 += 1)
            { 
                l_217 = (((l_217 < l_11[l_53]) != l_217) >= (-1L));
                return l_53;
            }
        }
    }
    return l_106;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 70
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 116
   depth: 2, occurrence: 37
   depth: 3, occurrence: 5
   depth: 4, occurrence: 9
   depth: 5, occurrence: 7
   depth: 6, occurrence: 4
   depth: 7, occurrence: 4
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 191
XXX times a non-volatile is write: 94
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 113
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 20
   depth: 2, occurrence: 34
   depth: 3, occurrence: 54

XXX percentage a fresh-made variable is used: 29.2
XXX percentage an existing variable is used: 70.8
XXX total OOB instances added: 0
********************* end of statistics **********************/

