/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00005.c -s 00005 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      5
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   uint64_t  f0;
   int8_t  f1;
};





static uint8_t  func_1(void);





static uint8_t  func_1(void)
{ 
    int8_t l_4[2];
    int32_t l_5[7];
    int32_t l_6 = 0xD44C039EL;
    int32_t l_17[3];
    int32_t l_40 = 1L;
    int i;
    for (i = 0; i < 2; i++)
        l_4[i] = 4L;
    for (i = 0; i < 7; i++)
        l_5[i] = 0xCA420452L;
    for (i = 0; i < 3; i++)
        l_17[i] = 8L;
    l_5[4] = (safe_rshift_func_int8_t_s_s(((l_4[1] > 6UL) >= 0xD2703D9B95031536LL), l_4[1]));
    for (l_6 = 6; (l_6 >= 0); l_6 -= 1)
    { 
        int32_t l_7 = 0L;
        int32_t l_12 = 0L;
        int32_t l_13 = 1L;
        int32_t l_14 = 0x095610A1L;
        int32_t l_15[10] = {0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL,0xFDFE924FL};
        int8_t l_19 = (-10L);
        int16_t l_20 = 0L;
        struct S0 l_31 = {0x7A8F60F1B6398C3DLL,0x4EL};
        int i;
        for (l_7 = 1; (l_7 >= 0); l_7 -= 1)
        { 
            int32_t l_8 = 0x86FD5D70L;
            int32_t l_16[5];
            uint8_t l_21[2];
            int64_t l_29[4];
            int i;
            for (i = 0; i < 5; i++)
                l_16[i] = 0xBAC8EF34L;
            for (i = 0; i < 2; i++)
                l_21[i] = 1UL;
            for (i = 0; i < 4; i++)
                l_29[i] = 0x87B34174AA7FCF62LL;
            for (l_8 = 0; (l_8 <= 1); l_8 += 1)
            { 
                int32_t l_11 = 0x9C8DDAC0L;
                int32_t l_18[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_18[i] = (-4L);
                l_11 ^= ((safe_div_func_uint16_t_u_u(l_5[(l_8 + 2)], l_4[l_7])) != 1L);
                l_21[1]++;
            }
            l_15[3] = 0xE85DC32CL;
            l_16[2] = l_4[l_7];
            for (l_19 = 1; (l_19 >= 0); l_19 -= 1)
            { 
                struct S0 l_30 = {0x2125954A43772679LL,0L};
                l_15[3] = (+((safe_div_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(((l_29[2] != 0xE6F96354D1843AD3LL) > l_6), 5L)), l_29[2])) || l_5[0]));
                l_5[6] = l_29[3];
                l_31 = l_30;
                return l_29[2];
            }
        }
        for (l_12 = 6; (l_12 >= 1); l_12 -= 1)
        { 
            uint32_t l_41 = 1UL;
            int i;
            for (l_19 = 0; (l_19 <= 2); l_19 += 1)
            { 
                int i;
                return l_5[(l_19 + 2)];
            }
            l_5[l_12] = (((safe_sub_func_uint8_t_u_u((((safe_add_func_int16_t_s_s(((safe_mul_func_int64_t_s_s((safe_lshift_func_int64_t_s_s(((l_5[l_12] > l_5[l_6]) ^ l_5[l_6]), 20)), l_5[l_12])) ^ l_14), (-6L))) != 0xC99B0BF1L) | l_40), l_41)) ^ l_19) == l_19);
        }
        l_13 = (safe_lshift_func_uint16_t_u_u((0L != l_5[l_6]), l_19));
        l_5[5] = (l_17[0] | l_17[0]);
    }
    l_6 &= (safe_rshift_func_uint32_t_u_s((safe_rshift_func_uint64_t_u_s((!(((safe_lshift_func_uint16_t_u_s(l_4[1], l_40)) < 65535UL) & 0x7C152A3E9F7A6BAELL)), l_5[1])), 2));
    return l_5[4];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 18
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6
   depth: 3, occurrence: 7

XXX percentage a fresh-made variable is used: 20.9
XXX percentage an existing variable is used: 79.1
XXX total OOB instances added: 0
********************* end of statistics **********************/

