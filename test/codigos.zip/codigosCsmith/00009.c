/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00009.c -s 00009 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      9
 */

#include "csmith.h"


static long __undefined;






static int8_t  func_1(void);





static int8_t  func_1(void)
{ 
    const int8_t l_3 = 0x02L;
    int32_t l_5 = 0xE57BF5CDL;
    int32_t l_6 = 8L;
    int32_t l_9 = (-1L);
    uint32_t l_11 = 0xF2D3F504L;
    uint64_t l_21 = 0x3E75CB5542AFA017LL;
    int32_t l_22[3];
    int32_t l_23[10] = {0xEC352115L,0xC7128ABFL,0xEC352115L,0xEC352115L,0xC7128ABFL,0xEC352115L,0xEC352115L,0xC7128ABFL,0xEC352115L,0xEC352115L};
    uint64_t l_24 = 18446744073709551615UL;
    int i;
    for (i = 0; i < 3; i++)
        l_22[i] = 1L;
    if ((safe_unary_minus_func_uint32_t_u(l_3)))
    { 
        int8_t l_4 = 0x1AL;
        int32_t l_7 = 0x6DEEC541L;
        int32_t l_8 = 0L;
        int32_t l_10[4];
        int i;
        for (i = 0; i < 4; i++)
            l_10[i] = 0x7D0FA516L;
        l_11--;
        return l_5;
    }
    else
    { 
        const uint64_t l_20 = 18446744073709551613UL;
        l_5 = (((safe_mod_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(0UL, l_20)), l_21)), l_9)) < 0x1780L) < 1L);
    }
    l_9 = l_9;
    l_9 ^= l_5;
    l_24--;
    return l_22[0];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 12
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 8
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 48.3
XXX percentage an existing variable is used: 51.7
XXX total OOB instances added: 0
********************* end of statistics **********************/

