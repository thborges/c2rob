/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00029.c -s 00029 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      29
 */

#include "csmith.h"


static long __undefined;






static int16_t  func_1(void);





static int16_t  func_1(void)
{ 
    uint32_t l_2[7] = {0x20624039L,0x20624039L,0x20624039L,0x20624039L,0x20624039L,0x20624039L,0x20624039L};
    int32_t l_3[1];
    const int64_t l_35 = 0x955F1BB1300CA3C4LL;
    int32_t l_36 = 0L;
    int32_t l_39 = 0L;
    int32_t l_45 = 0xF20BE86DL;
    int32_t l_48 = 2L;
    int32_t l_49 = (-7L);
    int32_t l_53[10] = {(-1L),0xB6AC8918L,0xB6AC8918L,(-1L),0xA3EBEF27L,(-1L),0xB6AC8918L,0xB6AC8918L,(-1L),0xA3EBEF27L};
    int32_t l_97 = (-7L);
    int32_t l_116 = 0L;
    int i;
    for (i = 0; i < 1; i++)
        l_3[i] = (-7L);
    for (l_3[0] = 0; (l_3[0] <= 6); l_3[0] += 1)
    { 
        int32_t l_37 = 0L;
        int32_t l_40 = 0xD660F181L;
        int32_t l_41[2];
        int8_t l_56 = 0xF1L;
        int64_t l_57 = (-1L);
        uint16_t l_80 = 0x263CL;
        int i;
        for (i = 0; i < 2; i++)
            l_41[i] = 8L;
        if (((safe_rshift_func_int16_t_s_s((safe_sub_func_int8_t_s_s((safe_rshift_func_uint32_t_u_u((((safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_mod_func_int64_t_s_s((safe_mul_func_int16_t_s_s(((safe_div_func_uint64_t_u_u((safe_add_func_int64_t_s_s(((safe_add_func_uint64_t_u_u(l_2[l_3[0]], l_2[l_3[0]])) <= l_3[0]), l_3[0])), 0x8D927F7B6FE6D39CLL)) <= l_2[l_3[0]]), 65527UL)), l_2[0])), l_2[l_3[0]])), 0xC1L)) > 0UL) >= l_2[l_3[0]]), l_3[0])), l_2[3])), l_3[0])) || 0x7F5AL))
        { 
            const uint16_t l_34 = 0x9C72L;
            int32_t l_42 = 0x95506909L;
            int32_t l_50 = 1L;
            int32_t l_54[9] = {(-7L),0xEAD4A2B5L,(-7L),0xEAD4A2B5L,(-7L),0xEAD4A2B5L,(-7L),0xEAD4A2B5L,(-7L)};
            int32_t l_58 = (-3L);
            uint32_t l_59 = 0x4FCE62B0L;
            uint64_t l_89 = 18446744073709551615UL;
            int i;
            if ((safe_lshift_func_uint32_t_u_s(((safe_mul_func_int8_t_s_s((safe_sub_func_int32_t_s_s((((safe_div_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(((l_2[0] & l_34) < 0xC90EL), 255UL)) <= l_35), l_3[0])) && 0x0AL) || l_3[0]), 0x00A9E1A0L)), 0x91L)) > l_34), l_34)))
            { 
                int32_t l_38 = (-9L);
                int8_t l_43 = (-2L);
                int32_t l_44 = (-1L);
                int32_t l_46 = 1L;
                int32_t l_47 = 0L;
                int32_t l_51 = 1L;
                int32_t l_52[5];
                int32_t l_55 = (-5L);
                int i;
                for (i = 0; i < 5; i++)
                    l_52[i] = 0x25CCEB8AL;
                l_59++;
            }
            else
            { 
                int32_t l_63[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_63[i] = 0x6825732EL;
                l_63[3] = (((!l_42) <= l_39) != l_41[0]);
                l_39 = 0x06514567L;
                l_54[8] = l_48;
            }
            if ((safe_add_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_s((safe_mul_func_int32_t_s_s((safe_div_func_int16_t_s_s(0xADB2L, l_34)), l_50)), 58)), l_37)))
            { 
                int64_t l_72 = 6L;
                l_54[2] = ((((255UL < l_72) || 0x600A8D5E9CB1239ELL) <= 1L) >= l_42);
                l_48 = (safe_div_func_int32_t_s_s(l_57, l_59));
            }
            else
            { 
                uint64_t l_75 = 1UL;
                uint32_t l_81[10] = {0x1EE4EC2AL,0xE414CEA6L,0UL,0xE414CEA6L,0x1EE4EC2AL,0x1EE4EC2AL,0xE414CEA6L,0UL,0xE414CEA6L,0x1EE4EC2AL};
                int i;
                l_75 |= (-1L);
                l_40 = (((((safe_mod_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(((((l_42 > l_75) | l_54[2]) || l_80) > 8L), l_54[4])) ^ l_53[7]), l_75)) | l_41[0]) && l_75) >= l_45) == l_75);
                l_81[0] = (((l_41[0] | l_53[6]) & l_42) | (-6L));
            }
            for (l_48 = 11; (l_48 == (-12)); l_48--)
            { 
                int64_t l_88 = 1L;
                int32_t l_90 = 1L;
                l_90 = (safe_mod_func_uint32_t_u_u((((safe_sub_func_uint16_t_u_u(l_49, l_88)) >= l_54[2]) ^ l_89), 5L));
                return l_56;
            }
        }
        else
        { 
            uint32_t l_91 = 0UL;
            l_91--;
            return l_37;
        }
        for (l_36 = 0; (l_36 < (-22)); l_36 = safe_sub_func_int32_t_s_s(l_36, 1))
        { 
            int32_t l_96 = 0L;
            int32_t l_104 = 1L;
            for (l_45 = 0; (l_45 <= 6); l_45 += 1)
            { 
                uint16_t l_98 = 0xE78DL;
                l_96 = (l_49 == l_53[9]);
                l_40 ^= ((l_41[0] & l_96) && l_96);
                l_97 = (0x9BE968035757FEC6LL > l_39);
                return l_98;
            }
            l_104 = (safe_sub_func_uint64_t_u_u((safe_unary_minus_func_int8_t_s((((((safe_unary_minus_func_uint8_t_u((!(l_2[l_3[0]] < l_3[0])))) <= l_96) != l_97) || 0xF10FL) >= l_96))), l_41[0]));
        }
        for (l_56 = (-10); (l_56 <= (-28)); l_56 = safe_sub_func_uint16_t_u_u(l_56, 7))
        { 
            l_41[0] = ((((safe_mod_func_uint8_t_u_u(251UL, l_41[1])) || 0xD2L) != l_53[3]) <= l_53[8]);
            l_41[0] = 0x732090DFL;
        }
        for (l_57 = 2; (l_57 <= 9); l_57 += 1)
        { 
            uint8_t l_112 = 0x0CL;
            if ((safe_div_func_uint16_t_u_u((safe_unary_minus_func_uint16_t_u(l_112)), l_97)))
            { 
                return l_53[7];
            }
            else
            { 
                int16_t l_115[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_115[i] = 0x12E9L;
                l_53[(l_3[0] + 3)] = (safe_lshift_func_uint32_t_u_s(l_115[0], l_116));
                l_37 = l_115[0];
            }
        }
    }
    l_3[0] = 0x038080D8L;
    return l_48;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 11
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 4
   depth: 7, occurrence: 1
   depth: 12, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 78
XXX times a non-volatile is write: 26
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 35
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 10
   depth: 3, occurrence: 18

XXX percentage a fresh-made variable is used: 20.5
XXX percentage an existing variable is used: 79.5
XXX total OOB instances added: 0
********************* end of statistics **********************/

