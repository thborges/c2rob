/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00027.c -s 00027 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      27
 */

#include "csmith.h"


static long __undefined;






static int16_t  func_1(void);





static int16_t  func_1(void)
{ 
    uint8_t l_4 = 0xE8L;
    int32_t l_17[7];
    uint64_t l_42 = 0x20B739032F82966BLL;
    int8_t l_57 = 0x44L;
    int32_t l_78 = 0x8E2CF014L;
    uint32_t l_86[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    uint32_t l_102 = 4294967292UL;
    uint32_t l_119 = 1UL;
    int32_t l_154 = 1L;
    const int32_t l_165 = 0x237AF674L;
    int i;
    for (i = 0; i < 7; i++)
        l_17[i] = 0x8C105A83L;
    if (((safe_div_func_uint32_t_u_u((l_4 && l_4), l_4)) | l_4))
    { 
        uint8_t l_10[10] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
        int32_t l_13 = 0x46C38250L;
        int32_t l_16 = 0x57A67D92L;
        int32_t l_20 = 0xF446CD5FL;
        int32_t l_22 = 0xF17245C2L;
        int32_t l_60 = 0x185AEBC5L;
        int32_t l_107 = 0xCCEA890DL;
        int i;
        for (l_4 = 0; (l_4 <= 36); l_4 = safe_add_func_uint16_t_u_u(l_4, 1))
        { 
            int32_t l_7 = 0x5E4B7834L;
            int32_t l_12 = 0x5251C607L;
            int32_t l_15 = (-3L);
            int32_t l_18 = 6L;
            int32_t l_21 = 9L;
            uint64_t l_26 = 0xC4433AC25417612DLL;
            for (l_7 = 0; (l_7 < 10); l_7 = safe_add_func_uint16_t_u_u(l_7, 1))
            { 
                uint32_t l_11 = 0xE813A3DBL;
                int32_t l_14 = 0x240CA700L;
                int32_t l_19 = 1L;
                uint8_t l_23 = 247UL;
                l_11 = ((l_7 < l_10[1]) & l_7);
                l_23--;
                l_26--;
            }
        }
        for (l_20 = (-25); (l_20 != 26); l_20 = safe_add_func_int8_t_s_s(l_20, 1))
        { 
            uint16_t l_31 = 0x07C4L;
            int32_t l_43 = (-1L);
            int64_t l_47 = 0x070A6219FF40B36FLL;
            int32_t l_49 = 0xA1AE281BL;
            int32_t l_54 = 0xDD9258C0L;
            int32_t l_56[1];
            int16_t l_87[2];
            int i;
            for (i = 0; i < 1; i++)
                l_56[i] = 3L;
            for (i = 0; i < 2; i++)
                l_87[i] = 1L;
            l_31++;
            for (l_22 = 0; (l_22 == (-18)); l_22 = safe_sub_func_uint64_t_u_u(l_22, 1))
            { 
                uint32_t l_46 = 5UL;
                int32_t l_48 = 8L;
                int32_t l_50 = 1L;
                int32_t l_51 = 0xD12EF611L;
                int32_t l_52 = 3L;
                int32_t l_53 = 0xBE90AECFL;
                int32_t l_55 = 0x41E97152L;
                int32_t l_58 = 0xD5A0A0DEL;
                int32_t l_59 = (-1L);
                int32_t l_61 = 0xDF464CC0L;
                int32_t l_62 = 4L;
                uint64_t l_63 = 18446744073709551606UL;
                l_43 = (safe_mod_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(((l_42 == 0x17A5L) ^ l_42), l_10[4])), 65535UL)), 0xFCD5L));
                l_13 = (safe_add_func_int16_t_s_s(((((0x06DFE53505CE4EC6LL || l_46) ^ 0xDA301817L) <= l_17[0]) & 0x78472532L), 0x5DD8L));
                l_63--;
                l_78 &= (safe_sub_func_int16_t_s_s((safe_mod_func_int8_t_s_s((((((safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_lshift_func_int32_t_s_s((0xC6DEL == 0x2E7EL), 2)), 248UL)), 0L)), l_62)) && 0x1A7EL) || 0xFA7F9CD9L) ^ 0x0AL) == l_54), l_17[0])), l_63));
            }
            if (((((safe_sub_func_int64_t_s_s((((safe_unary_minus_func_int64_t_s(l_17[0])) != 9UL) >= 1UL), l_78)) > l_22) < l_17[2]) == l_20))
            { 
                l_54 = (safe_add_func_uint64_t_u_u(l_4, l_47));
                l_16 ^= 1L;
            }
            else
            { 
                l_22 = ((((safe_sub_func_uint64_t_u_u(0x5F501B3ADA1D0942LL, (-6L))) <= l_10[1]) == 1L) || 0x47D5L);
                l_13 = (((l_86[0] > l_86[7]) < l_42) == 0x4CL);
                return l_42;
            }
            l_87[1] ^= l_17[0];
        }
        for (l_4 = 1; (l_4 <= 7); l_4 += 1)
        { 
            int i;
            l_22 &= (safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(0xCBCDL, l_86[l_4])) <= 6UL), 4)), l_86[7]));
            l_17[4] = (-1L);
        }
        for (l_16 = 0; (l_16 <= 9); l_16 += 1)
        { 
            int32_t l_94[2];
            int i;
            for (i = 0; i < 2; i++)
                l_94[i] = 0L;
            l_94[0] = (l_10[l_16] > 7UL);
            l_20 = l_86[0];
            for (l_78 = 3; (l_78 <= 9); l_78 += 1)
            { 
                int16_t l_100[6] = {0xABDEL,0xEC41L,0xABDEL,0xABDEL,0xEC41L,0xABDEL};
                int32_t l_101 = (-10L);
                int32_t l_105 = 0xE681A9B7L;
                int32_t l_106 = 0x0A8C2178L;
                uint64_t l_108 = 0xDFC10558E765C773LL;
                int i;
                l_101 = (safe_div_func_uint64_t_u_u((((~(!((((~0xCEL) || l_94[0]) | 250UL) >= l_10[l_16]))) && l_100[4]) < 0xFC04L), 0xFD2E0221BC3F5551LL));
                l_102--;
                l_108--;
                l_94[1] = (((safe_add_func_uint32_t_u_u((safe_div_func_int64_t_s_s((safe_sub_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(((l_86[0] != (-6L)) == l_57), 6)), l_119)), l_4)), 0x26758D62L)) != l_42) < l_105);
            }
        }
    }
    else
    { 
        uint8_t l_121 = 0xCCL;
        uint64_t l_145 = 0x86CC2DAEADAD7837LL;
        int32_t l_149 = 0xE63F1C0EL;
        for (l_57 = 6; (l_57 >= 0); l_57 -= 1)
        { 
            for (l_4 = 0; (l_4 <= 7); l_4 += 1)
            { 
                int32_t l_120 = 0x40340A1BL;
                int i;
                l_121--;
                return l_86[(l_57 + 1)];
            }
            return l_102;
        }
        for (l_102 = 0; (l_102 != 9); l_102++)
        { 
            int8_t l_135 = 0x49L;
            int32_t l_136 = 0x2DAA5A9DL;
            int32_t l_139 = (-1L);
            int16_t l_141 = (-1L);
            for (l_57 = 0; (l_57 <= 7); l_57 += 1)
            { 
                int32_t l_126[9] = {0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L,0x21CF7329L};
                int i;
                l_126[2] ^= l_86[l_57];
                l_136 &= ((((((safe_rshift_func_int32_t_s_u((((safe_sub_func_int32_t_s_s((safe_mod_func_int8_t_s_s((l_119 & l_126[2]), 1UL)), 1UL)) | l_86[l_57]) ^ l_86[l_57]), l_86[l_57])) <= l_135) & l_135) & l_121) || l_126[2]) ^ 0L);
            }
            for (l_135 = 23; (l_135 >= (-10)); l_135 = safe_sub_func_uint32_t_u_u(l_135, 1))
            { 
                int64_t l_142[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                int32_t l_146 = (-1L);
                int i;
                l_139 ^= l_136;
                l_142[1] = (safe_unary_minus_func_int16_t_s(((l_57 ^ l_141) | 0xECE6L)));
                l_136 ^= (safe_add_func_int16_t_s_s(l_142[4], l_121));
                l_146 = (l_141 > l_145);
            }
            l_149 ^= (safe_rshift_func_int16_t_s_s((1UL == l_136), 10));
        }
        l_17[3] = (safe_lshift_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u(l_17[5], l_145)) || l_102), l_154));
        l_149 = (safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_s((safe_mod_func_uint32_t_u_u(((safe_lshift_func_int64_t_s_u((safe_mul_func_int8_t_s_s((l_145 < 0xB5FDL), l_17[1])), 60)) == 0xD2ADL), l_154)), 6)), 15));
    }
    l_17[0] = l_165;
    return l_4;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 62
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 50
   depth: 2, occurrence: 16
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 83
XXX times a non-volatile is write: 44
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 50
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 8
   depth: 2, occurrence: 15
   depth: 3, occurrence: 24

XXX percentage a fresh-made variable is used: 38.3
XXX percentage an existing variable is used: 61.7
XXX total OOB instances added: 0
********************* end of statistics **********************/

