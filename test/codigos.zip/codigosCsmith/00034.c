/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00034.c -s 00034 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      34
 */

#include "csmith.h"


static long __undefined;






static int32_t  func_1(void);





static int32_t  func_1(void)
{ 
    int32_t l_2 = (-1L);
    int32_t l_20 = (-1L);
    int32_t l_26[1];
    uint16_t l_36 = 0x6E66L;
    uint16_t l_37 = 65535UL;
    uint64_t l_38 = 0x25036FFE617092FFLL;
    int i;
    for (i = 0; i < 1; i++)
        l_26[i] = 0x4D64EA33L;
    for (l_2 = 0; (l_2 <= (-22)); l_2 = safe_sub_func_uint32_t_u_u(l_2, 1))
    { 
        int8_t l_5 = (-5L);
        int32_t l_35 = 0xB6062CF9L;
        l_5 = l_2;
        for (l_5 = 0; (l_5 <= 23); l_5 = safe_add_func_uint32_t_u_u(l_5, 1))
        { 
            int32_t l_8 = 8L;
            int32_t l_15 = 1L;
            int32_t l_25[1];
            int i;
            for (i = 0; i < 1; i++)
                l_25[i] = 0xC279A20BL;
            for (l_8 = (-5); (l_8 <= (-18)); l_8 = safe_sub_func_uint8_t_u_u(l_8, 1))
            { 
                return l_8;
            }
            for (l_8 = 0; (l_8 <= 20); l_8++)
            { 
                l_15 = (safe_mod_func_uint32_t_u_u(l_8, 4294967293UL));
                l_20 = ((safe_mod_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u((l_15 != l_15), l_2)), 0xFADFL)) > l_5);
                l_25[0] |= (safe_rshift_func_uint8_t_u_u(((safe_rshift_func_int32_t_s_u(l_8, l_15)) & l_8), 4));
            }
        }
        for (l_20 = 0; (l_20 <= 0); l_20 += 1)
        { 
            const uint8_t l_33[5] = {0xA8L,0xA8L,0xA8L,0xA8L,0xA8L};
            int64_t l_34 = 0xDAF0B56FE18BD2E8LL;
            int i;
            for (l_5 = 0; (l_5 >= 0); l_5 -= 1)
            { 
                int i;
                l_34 = ((((((((safe_sub_func_int8_t_s_s(((safe_add_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(l_26[l_20], 9)), 0x70L)) >= l_5), l_5)) & l_20) == l_5) ^ l_26[0]) != l_26[0]) != 0x550EL) != 0xCF8FB6F85A06C0F1LL) == l_33[1]);
                l_35 = 0x2406C49AL;
            }
            l_36 = 0x8552AD14L;
        }
    }
    l_20 = l_37;
    return l_38;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 7
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 14
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 3
   depth: 2, occurrence: 4
   depth: 3, occurrence: 6

XXX percentage a fresh-made variable is used: 37
XXX percentage an existing variable is used: 63
XXX total OOB instances added: 0
********************* end of statistics **********************/

