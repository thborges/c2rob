/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00010.c -s 00010 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      10
 */

#include "csmith.h"


static long __undefined;


struct S1 {
   signed f0 : 11;
   signed f1 : 27;
};





static const uint64_t  func_1(void);





static const uint64_t  func_1(void)
{ 
    int32_t l_2 = (-7L);
    uint64_t l_5[10] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    int32_t l_31[5] = {0x28543B57L,0x28543B57L,0x28543B57L,0x28543B57L,0x28543B57L};
    int i;
    for (l_2 = 0; (l_2 != (-3)); l_2 = safe_sub_func_int32_t_s_s(l_2, 3))
    { 
        int32_t l_6[4];
        int32_t l_7 = (-6L);
        struct S1 l_8 = {18,-353};
        int32_t l_20 = 0x005AB136L;
        uint16_t l_45 = 0x3CBCL;
        int i;
        for (i = 0; i < 4; i++)
            l_6[i] = 7L;
        for (l_6[1] = 9; (l_6[1] >= 0); l_6[1] -= 1)
        { 
            struct S1 l_9[5] = {{31,3165},{31,3165},{31,3165},{31,3165},{31,3165}};
            int i;
            l_7 ^= ((0L > 0x2DL) & 5UL);
            l_9[1] = l_8;
        }
        for (l_7 = 3; (l_7 >= 0); l_7 -= 1)
        { 
            int32_t l_10[8] = {0x016488A9L,0x016488A9L,0x016488A9L,0x016488A9L,0x016488A9L,0x016488A9L,0x016488A9L,0x016488A9L};
            int32_t l_26 = 0L;
            int i;
            for (l_10[0] = 0; (l_10[0] <= 9); l_10[0] += 1)
            { 
                int32_t l_21[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
                int i;
                l_21[1] ^= ((safe_rshift_func_int16_t_s_u((safe_mul_func_int64_t_s_s(((+(safe_lshift_func_int64_t_s_u(((safe_lshift_func_int32_t_s_u((0x56540F21L >= l_6[l_7]), l_5[l_10[0]])) | l_10[3]), 3))) & l_10[0]), 0xC3B03C3FA3C9E4A0LL)), l_20)) && l_10[0]);
                l_26 = (safe_sub_func_int32_t_s_s(((safe_mod_func_int16_t_s_s(((l_5[4] || l_2) ^ l_6[1]), l_6[l_7])) != 0x65296947L), l_8.f1));
                l_26 |= ((safe_div_func_int64_t_s_s((((((-8L) <= 0xAEL) && 0x021F5EB7L) | l_21[0]) < l_5[l_10[0]]), (-1L))) >= l_2);
            }
            for (l_20 = 0; (l_20 <= 3); l_20 += 1)
            { 
                int64_t l_29 = 0x3002E9D3B05E2623LL;
                int32_t l_30[4] = {(-1L),(-1L),(-1L),(-1L)};
                int32_t l_32 = 4L;
                uint16_t l_33 = 65535UL;
                int8_t l_38 = 1L;
                int i;
                l_33--;
                l_38 = ((safe_mod_func_uint32_t_u_u(0xCA2468F5L, l_6[l_7])) || l_5[(l_7 + 2)]);
                l_10[7] = (safe_mod_func_int8_t_s_s((safe_mul_func_uint64_t_u_u(((safe_add_func_uint32_t_u_u((1L == 5L), l_10[0])) > 1UL), 0xAD7CBC17640197F5LL)), l_7));
            }
            l_45++;
        }
        l_31[3] = l_20;
    }
    return l_31[2];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 2
breakdown:
   indirect level: 0, occurrence: 2
XXX full-bitfields structs in the program: 2
breakdown:
   indirect level: 0, occurrence: 2
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 1
XXX times a bitfields struct on RHS: 1
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 1

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 3
   depth: 2, occurrence: 5
   depth: 3, occurrence: 6

XXX percentage a fresh-made variable is used: 15.1
XXX percentage an existing variable is used: 84.9
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

