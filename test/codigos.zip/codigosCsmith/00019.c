/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00019.c -s 00019 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      19
 */

#include "csmith.h"


static long __undefined;






static int32_t  func_1(void);





static int32_t  func_1(void)
{ 
    int32_t l_2 = 0xDF99FF60L;
    int32_t l_11 = 0x2EA21E1DL;
    int32_t l_12 = 0x2E9378F1L;
    int32_t l_13 = 3L;
    int32_t l_23 = 9L;
    uint16_t l_28 = 65535UL;
    for (l_2 = (-13); (l_2 >= 5); l_2++)
    { 
        uint16_t l_5[8] = {0x96A4L,65531UL,0x96A4L,0x96A4L,65531UL,0x96A4L,0x96A4L,65531UL};
        int32_t l_6[4] = {0L,0L,0L,0L};
        int32_t l_7 = (-3L);
        int32_t l_14 = 0x1362395EL;
        uint64_t l_17 = 0x002891BA80278EE3LL;
        int8_t l_22[7];
        int8_t l_29 = (-1L);
        int i;
        for (i = 0; i < 7; i++)
            l_22[i] = 0xCFL;
        for (l_6[3] = 7; (l_6[3] >= 2); l_6[3] -= 1)
        { 
            int32_t l_10 = 0x80BFB3A4L;
            int32_t l_15[6] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
            int32_t l_16 = 0x3C017F21L;
            int i;
            l_7 = l_2;
            for (l_7 = 0; (l_7 <= 7); l_7 += 1)
            { 
                l_11 = (((safe_lshift_func_int32_t_s_s(1L, l_6[1])) != l_10) >= l_6[3]);
                l_17++;
            }
        }
        for (l_13 = 0; (l_13 < 24); l_13++)
        { 
            uint32_t l_24 = 0x90DFC1F7L;
            l_24--;
            l_29 = ((~l_28) >= 0UL);
            for (l_12 = 3; (l_12 >= 0); l_12 -= 1)
            { 
                int i;
                return l_6[l_12];
            }
        }
        return l_28;
    }
    return l_12;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 6
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 3
   depth: 2, occurrence: 5
   depth: 3, occurrence: 3

XXX percentage a fresh-made variable is used: 58.3
XXX percentage an existing variable is used: 41.7
XXX total OOB instances added: 0
********************* end of statistics **********************/

