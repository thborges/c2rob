/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00042.c -s 00042 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      42
 */

#include "csmith.h"


static long __undefined;






static const int8_t  func_1(void);





static const int8_t  func_1(void)
{ 
    int32_t l_2 = (-5L);
    int32_t l_16 = 0x4DA86284L;
    int32_t l_28 = 0xDDC87778L;
    uint32_t l_37 = 1UL;
    for (l_2 = 2; (l_2 != (-4)); l_2 = safe_sub_func_int32_t_s_s(l_2, 6))
    { 
        uint8_t l_12[10] = {1UL,0x87L,0xD2L,0xD2L,0x87L,1UL,0x87L,0xD2L,0xD2L,0x87L};
        int32_t l_20 = 0x5EBDA184L;
        int i;
        if ((safe_add_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((safe_rshift_func_int32_t_s_u((0x59609C3FBB4EBB0CLL && 0xE31551DA622A149CLL), 12)), l_2)), l_2)))
        { 
            int64_t l_11 = 0xADF1ADB2BC40ED3CLL;
            l_12[4] = l_11;
        }
        else
        { 
            uint32_t l_14[5] = {0xA6C9CD49L,0xA6C9CD49L,0xA6C9CD49L,0xA6C9CD49L,0xA6C9CD49L};
            int16_t l_15 = (-1L);
            int i;
            l_15 |= (safe_unary_minus_func_uint8_t_u(l_14[1]));
            l_16 = 0xDA8ED40AL;
        }
        for (l_16 = 0; (l_16 != 13); l_16 = safe_add_func_int32_t_s_s(l_16, 1))
        { 
            const uint32_t l_19[3] = {9UL,9UL,9UL};
            int i;
            l_20 = l_19[2];
        }
        for (l_16 = 0; (l_16 == (-7)); l_16 = safe_sub_func_int8_t_s_s(l_16, 1))
        { 
            uint8_t l_36[10] = {0x11L,0x11L,0x11L,0x11L,0x11L,0x11L,0x11L,0x11L,0x11L,0x11L};
            int i;
            for (l_20 = 0; (l_20 != (-15)); l_20 = safe_sub_func_uint16_t_u_u(l_20, 5))
            { 
                int32_t l_31 = 1L;
                l_28 = (safe_mod_func_uint16_t_u_u(((~(0x9EL || (-1L))) || 0L), 0x41B8L));
                l_28 = (safe_sub_func_uint64_t_u_u(l_31, (-5L)));
                l_28 = (l_16 > l_31);
            }
            l_28 = ((safe_sub_func_int64_t_s_s((((safe_add_func_int8_t_s_s(0x5CL, l_36[7])) & (-1L)) & l_37), l_20)) <= l_28);
        }
        if ((safe_add_func_int64_t_s_s(l_37, l_28)))
        { 
            int16_t l_45 = 0L;
            int32_t l_52 = 0x3B05E262L;
            for (l_28 = 20; (l_28 <= 26); l_28 = safe_add_func_uint8_t_u_u(l_28, 1))
            { 
                uint32_t l_44 = 0xB4D633C6L;
                l_45 |= ((safe_div_func_int32_t_s_s((l_44 >= l_44), 1UL)) != 7L);
                l_20 &= (safe_add_func_int32_t_s_s(l_37, l_37));
                l_52 = (((safe_sub_func_int32_t_s_s(((safe_div_func_int16_t_s_s(l_12[3], l_20)) | l_28), l_45)) != (-1L)) == 1L);
                return l_52;
            }
            l_20 = (safe_unary_minus_func_int16_t_s(0L));
        }
        else
        { 
            uint32_t l_54 = 0xE65120B8L;
            for (l_20 = 9; (l_20 >= 3); l_20 -= 1)
            { 
                int i;
                return l_12[l_20];
            }
            l_20 |= (l_54 > l_54);
        }
    }
    l_28 = (l_28 == 0x1012106DL);
    return l_37;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 12
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 34
XXX times a non-volatile is write: 20
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 25
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 10
   depth: 3, occurrence: 8

XXX percentage a fresh-made variable is used: 36.6
XXX percentage an existing variable is used: 63.4
XXX total OOB instances added: 0
********************* end of statistics **********************/

