/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00049.c -s 00049 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      49
 */

#include "csmith.h"


static long __undefined;


struct S1 {
   unsigned f0 : 30;
   unsigned : 0;
   signed f1 : 15;
   signed f2 : 25;
};





static uint32_t  func_1(void);





static uint32_t  func_1(void)
{ 
    uint64_t l_2[6] = {0x8F01BA028EA38884LL,0xCB143E95AAD8530DLL,0x8F01BA028EA38884LL,0x8F01BA028EA38884LL,0xCB143E95AAD8530DLL,0x8F01BA028EA38884LL};
    int32_t l_3 = (-10L);
    int32_t l_30 = 5L;
    int32_t l_36[10] = {0x8FEFD6E5L,0L,0x8FEFD6E5L,0x8FEFD6E5L,0L,0x8FEFD6E5L,0x8FEFD6E5L,0L,0x8FEFD6E5L,0x8FEFD6E5L};
    uint16_t l_45[3];
    struct S1 l_51 = {15884,-36,-4278};
    int32_t l_77 = (-6L);
    int32_t l_110 = 0x0FD57B23L;
    int64_t l_141 = 0x0F91DEE43BDDC6D7LL;
    int i;
    for (i = 0; i < 3; i++)
        l_45[i] = 0x7A31L;
    for (l_3 = 0; (l_3 <= 5); l_3 += 1)
    { 
        int32_t l_39 = 0x0E9505C0L;
        int32_t l_41 = 0L;
        int32_t l_42 = 8L;
        int32_t l_43 = (-7L);
        int32_t l_44 = 0x4E19C781L;
        int32_t l_53 = 0xBA9A64B0L;
        int32_t l_54 = 3L;
        int32_t l_70 = 1L;
        int32_t l_72 = 0xF3F00C75L;
        int32_t l_73 = 0xB3B6DF64L;
        int32_t l_78 = 0xB02009A6L;
        int8_t l_80[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        int32_t l_82 = (-2L);
        int32_t l_83[10] = {0x97ADA246L,0L,0L,0x97ADA246L,0L,0x97ADA246L,0L,0L,0x97ADA246L,0L};
        uint32_t l_84 = 0xBDB463C3L;
        int16_t l_109 = (-2L);
        int64_t l_112 = (-10L);
        uint32_t l_113 = 1UL;
        uint32_t l_149 = 0UL;
        struct S1 l_176 = {689,175,-44};
        int i;
        if (((l_2[l_3] & l_2[l_3]) | (-7L)))
        { 
            int32_t l_4[4];
            int32_t l_31 = 0L;
            uint8_t l_32[10] = {0xD3L,0xBBL,0xBBL,0xD3L,0x97L,0xD3L,0xBBL,0xBBL,0xD3L,0x97L};
            int i;
            for (i = 0; i < 4; i++)
                l_4[i] = 0xB90F9986L;
            for (l_4[0] = 4; (l_4[0] >= 1); l_4[0] -= 1)
            { 
                const uint8_t l_13[2] = {0UL,0UL};
                int32_t l_14[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                uint64_t l_29 = 0x18394D2570D97802LL;
                int i;
                l_14[2] = ((safe_lshift_func_uint32_t_u_u((safe_mod_func_int16_t_s_s(((((safe_rshift_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((l_4[1] <= l_13[0]), l_4[2])), l_13[0])) ^ l_2[l_3]) ^ l_4[0]) && 0xA5B5CF0AL), l_2[l_3])), 14)) | 0UL);
                l_31 ^= (safe_div_func_uint16_t_u_u(((((safe_mul_func_uint32_t_u_u((safe_mul_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((safe_div_func_int32_t_s_s((safe_mod_func_int64_t_s_s((safe_sub_func_uint8_t_u_u((l_14[6] || l_29), l_3)), l_2[l_3])), l_30)) == l_2[l_3]), l_2[l_3])), l_4[0])), l_3)) != l_14[3]) || l_30) || l_2[l_3]), l_29));
                return l_3;
            }
            l_32[5] &= l_3;
        }
        else
        { 
            int16_t l_35 = 0x04E2L;
            int32_t l_37 = 1L;
            int32_t l_38 = 1L;
            int32_t l_40[7] = {0x458AF326L,0x1EF224B3L,0x458AF326L,0x458AF326L,0x1EF224B3L,0x458AF326L,0x458AF326L};
            uint32_t l_55 = 0xD48012CFL;
            int8_t l_62 = (-2L);
            int i;
            for (l_30 = 5; (l_30 >= 0); l_30 -= 1)
            { 
                struct S1 l_50 = {25628,112,-1084};
                l_36[7] = (safe_div_func_int8_t_s_s(l_35, l_2[1]));
                l_45[1]++;
                l_36[9] = ((safe_add_func_uint16_t_u_u(l_38, 0xE926L)) >= 3UL);
                l_51 = l_50;
            }
            for (l_30 = 4; (l_30 >= 1); l_30 -= 1)
            { 
                int32_t l_52 = (-1L);
                l_52 |= l_39;
            }
            for (l_30 = 0; (l_30 <= 5); l_30 += 1)
            { 
                return l_37;
            }
            for (l_38 = 4; (l_38 >= 0); l_38 -= 1)
            { 
                int i;
                l_55--;
                l_62 = (safe_lshift_func_int8_t_s_u(((safe_mod_func_uint8_t_u_u(((8L & l_2[(l_38 + 1)]) >= l_2[(l_38 + 1)]), l_36[9])) > l_43), 4));
            }
        }
        if ((safe_lshift_func_int8_t_s_s((l_3 > l_3), l_45[0])))
        { 
            int8_t l_65 = 0x1DL;
            int32_t l_66 = 0x17EA5CA4L;
            int32_t l_67 = 0x074354AFL;
            int32_t l_68 = 0x5026E73BL;
            int32_t l_69 = 0x0B65BDA1L;
            int32_t l_71 = 0xBD2431EAL;
            int32_t l_74 = (-1L);
            int32_t l_75 = 0x489CA1FCL;
            int32_t l_76 = 1L;
            int32_t l_79 = 5L;
            int32_t l_81 = 0x4FF55BD2L;
            uint32_t l_118 = 0xB521C193L;
            int16_t l_124 = 1L;
            uint16_t l_125 = 65533UL;
            int32_t l_140[1];
            int i;
            for (i = 0; i < 1; i++)
                l_140[i] = 2L;
            l_84++;
            if (l_51.f0)
            { 
                return l_80[2];
            }
            else
            { 
                uint32_t l_89 = 2UL;
                uint32_t l_106 = 0x713F97C6L;
                int32_t l_107 = 0x969C76AAL;
                int32_t l_108 = 0L;
                int32_t l_111[9] = {4L,4L,0x8DFD1F3BL,4L,4L,0x8DFD1F3BL,4L,4L,0x8DFD1F3BL};
                int i;
                l_54 = ((safe_mod_func_uint64_t_u_u((0x16D0L & l_89), 0x12068ECBDE39F743LL)) >= l_89);
                l_36[3] |= ((safe_mul_func_int8_t_s_s((safe_div_func_int32_t_s_s((safe_mul_func_int32_t_s_s((safe_lshift_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u(((safe_mul_func_int64_t_s_s((safe_lshift_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u((((1L == 65529UL) & l_83[5]) < (-6L)), l_30)), l_76)), l_43)) == (-3L)), l_84)), l_106)), 0xB757F9C6L)), 0xC73EBF55L)), l_2[4])) != l_66);
                l_113++;
                l_51.f1 &= ((safe_lshift_func_uint64_t_u_u(((9L == l_108) != l_118), 1)) > l_51.f0);
            }
            if (((((l_3 != l_39) <= l_74) || 0xE1C8L) || l_81))
            { 
                uint32_t l_123 = 6UL;
                uint32_t l_134 = 0x8892B40EL;
                l_83[1] = ((~(+(((((safe_div_func_uint8_t_u_u(l_44, l_123)) <= l_124) <= l_125) <= l_74) >= l_123))) & l_36[4]);
                l_51.f1 = ((safe_mod_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_mul_func_uint64_t_u_u(((safe_mul_func_uint32_t_u_u(l_68, 0x02DCD109L)) ^ l_36[8]), l_112)), l_134)), l_2[4])) && l_67);
                return l_51.f2;
            }
            else
            { 
                int32_t l_135 = 1L;
                int32_t l_142 = (-4L);
                int32_t l_143 = 5L;
                int32_t l_144 = 0L;
                int32_t l_145 = 7L;
                int16_t l_146 = 2L;
                int32_t l_147 = (-3L);
                int32_t l_148[9] = {0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL,0x4BF25F1CL};
                int i;
                l_135 ^= 0xA23E10E1L;
                l_82 |= (((safe_sub_func_int32_t_s_s((18446744073709551608UL > 1UL), l_44)) || l_135) >= l_77);
                l_78 = (safe_rshift_func_uint16_t_u_s(((l_135 >= 1UL) > l_112), l_135));
                l_149--;
            }
            l_36[1] = 1L;
        }
        else
        { 
            uint16_t l_160 = 65535UL;
            struct S1 l_177 = {31771,-52,-1552};
            int32_t l_182 = (-1L);
            const int32_t l_190 = (-1L);
            if ((safe_add_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(0x299FL, l_80[4])), 2)), l_36[7])), l_160)))
            { 
                const int32_t l_175[6] = {3L,3L,3L,3L,3L,3L};
                int i;
                l_30 = ((safe_add_func_int32_t_s_s((safe_div_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((!(((((safe_div_func_int8_t_s_s(((~l_175[4]) & l_30), l_141)) == l_80[4]) | (-4L)) > 0xF0CFL) <= l_43)), l_160)), l_109)) < l_160), l_160)), l_36[8])), l_141)) ^ l_175[2]);
                l_177 = l_176;
                l_36[7] = (-1L);
                l_182 &= ((safe_mod_func_int64_t_s_s((((safe_lshift_func_int64_t_s_u(l_177.f1, 47)) & 0x1A96804CL) == l_177.f2), 1UL)) < 9L);
            }
            else
            { 
                l_51.f2 |= (safe_mul_func_int16_t_s_s((~(safe_lshift_func_uint64_t_u_u(6UL, 7))), 0UL));
            }
            for (l_109 = 4; (l_109 >= 1); l_109 -= 1)
            { 
                int i;
                l_177 = l_176;
                l_36[(l_3 + 3)] ^= (safe_sub_func_uint32_t_u_u(((l_83[(l_109 + 4)] & l_2[(l_109 + 1)]) < l_45[1]), l_190));
            }
        }
        return l_141;
    }
    return l_36[3];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 71
   depth: 1, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 4
XXX zero bitfields defined in structs: 1
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 4
breakdown:
   indirect level: 0, occurrence: 4
XXX full-bitfields structs in the program: 4
breakdown:
   indirect level: 0, occurrence: 4
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 3
XXX times a bitfields struct on RHS: 3
XXX times a single bitfield on LHS: 3
XXX times a single bitfield on RHS: 5

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 8
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 108
XXX times a non-volatile is write: 36
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 47
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 3
   depth: 2, occurrence: 12
   depth: 3, occurrence: 30

XXX percentage a fresh-made variable is used: 28.7
XXX percentage an existing variable is used: 71.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

