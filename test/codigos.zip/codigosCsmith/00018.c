/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00018.c -s 00018 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      18
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   int32_t  f0;
   int16_t  f1;
   int32_t  f2;
   int16_t  f3;
   uint64_t  f4;
   int32_t  f5;
};





static int64_t  func_1(void);





static int64_t  func_1(void)
{ 
    int32_t l_2[3];
    int32_t l_3 = 0xB9C2D621L;
    uint8_t l_16 = 0x2BL;
    struct S0 l_19 = {-5L,4L,0L,0x05ABL,0UL,0x84365721L};
    int16_t l_98 = 1L;
    int i;
    for (i = 0; i < 3; i++)
        l_2[i] = 0x0244C3F4L;
    l_2[0] |= (0x1D59L && 0xEA0DL);
    for (l_3 = 18; (l_3 >= (-12)); l_3 = safe_sub_func_int8_t_s_s(l_3, 2))
    { 
        int32_t l_17 = 4L;
        int32_t l_18 = 0L;
        struct S0 l_20[3] = {{0xE4879289L,0xF433L,0x8A0C0902L,4L,0x49EF57A55752783DLL,4L},{0xE4879289L,0xF433L,0x8A0C0902L,4L,0x49EF57A55752783DLL,4L},{0xE4879289L,0xF433L,0x8A0C0902L,4L,0x49EF57A55752783DLL,4L}};
        int32_t l_40 = 0L;
        uint32_t l_75 = 0x78F30ED5L;
        int32_t l_85 = (-8L);
        int32_t l_89 = (-3L);
        int32_t l_91 = 0x48F550CBL;
        int32_t l_92 = (-6L);
        int32_t l_94 = 2L;
        int32_t l_95 = 0xF678E9A5L;
        int32_t l_96[9] = {0L,9L,0L,0L,9L,0L,0L,9L,0L};
        int64_t l_121 = 1L;
        int32_t l_124[2];
        int i;
        for (i = 0; i < 2; i++)
            l_124[i] = 0x59527933L;
        if (((+l_2[2]) <= l_3))
        { 
            int8_t l_11 = (-1L);
            const int64_t l_33 = 0x13735CA718BA309CLL;
            if ((safe_sub_func_int16_t_s_s((safe_mul_func_uint32_t_u_u(1UL, l_11)), l_3)))
            { 
                return l_3;
            }
            else
            { 
                l_18 = (safe_sub_func_uint8_t_u_u((safe_div_func_int16_t_s_s((l_16 < l_17), l_11)), l_16));
                l_20[2] = l_19;
                l_19.f2 = (safe_sub_func_int16_t_s_s(0x96DAL, 0xBE77L));
            }
            if (((safe_sub_func_int16_t_s_s((safe_div_func_uint64_t_u_u(l_11, 0x8E9D28BC130268D9LL)), l_11)) < l_2[2]))
            { 
                return l_11;
            }
            else
            { 
                int64_t l_27[3];
                int32_t l_30[7] = {1L,1L,1L,1L,1L,1L,1L};
                int i;
                for (i = 0; i < 3; i++)
                    l_27[i] = 0x74462D17F4926A67LL;
                l_18 |= ((6UL || l_19.f2) && 0x1EB1ED30L);
                l_27[0] |= 0xCEFC6E20L;
                l_30[6] |= (safe_sub_func_int64_t_s_s((-1L), l_27[0]));
            }
            for (l_19.f3 = (-14); (l_19.f3 == 15); l_19.f3 = safe_add_func_uint16_t_u_u(l_19.f3, 7))
            { 
                return l_11;
            }
            l_2[0] = ((255UL >= 255UL) && l_33);
        }
        else
        { 
            const uint8_t l_35 = 5UL;
            int64_t l_41[2];
            int i;
            for (i = 0; i < 2; i++)
                l_41[i] = 0x0973F91A66538695LL;
            l_18 = (+((((l_35 == l_20[2].f1) != l_3) != 0x1DL) == l_17));
            for (l_19.f0 = 0; (l_19.f0 == (-6)); l_19.f0 = safe_sub_func_int16_t_s_s(l_19.f0, 8))
            { 
                l_19.f2 = (-2L);
                return l_35;
            }
            l_20[2].f2 = ((safe_mul_func_uint16_t_u_u((l_35 & l_35), l_40)) != l_41[0]);
        }
        for (l_19.f4 = 0; (l_19.f4 <= 2); l_19.f4 += 1)
        { 
            int i;
            l_20[2].f2 ^= (~l_2[l_19.f4]);
        }
        for (l_17 = (-20); (l_17 < (-5)); l_17++)
        { 
            int8_t l_51 = 0x0BL;
            uint32_t l_55 = 18446744073709551615UL;
            int32_t l_61 = 0x4C43DCC5L;
            struct S0 l_80 = {0xE4A0A603L,0L,-6L,0L,18446744073709551615UL,7L};
            int16_t l_86[7] = {0x6640L,0x6640L,0x0E34L,0x6640L,0x6640L,0x0E34L,0x6640L};
            int32_t l_93 = 0x37DEDC86L;
            int32_t l_97 = 0xA727D4F9L;
            int32_t l_99 = 0xE2934973L;
            uint64_t l_100 = 0x1F57036DBD5D31C8LL;
            int i;
            for (l_40 = 0; (l_40 >= 17); l_40 = safe_add_func_uint16_t_u_u(l_40, 4))
            { 
                const int64_t l_52 = 0x9FF52682FBA83E1ALL;
                l_20[2].f2 ^= ((+((safe_add_func_uint8_t_u_u(((safe_unary_minus_func_uint8_t_u(l_20[2].f3)) >= 0x2358L), l_51)) != l_16)) < l_52);
                l_18 = l_51;
                l_19.f2 = (safe_div_func_int16_t_s_s((-9L), l_55));
            }
            if (((l_17 == l_51) & l_20[2].f0))
            { 
                int8_t l_58[7] = {0xBEL,0xBEL,0xBEL,0xBEL,0xBEL,0xBEL,0xBEL};
                const uint32_t l_59 = 0x94F54D63L;
                int32_t l_60[9] = {0xFAD406D4L,0xFEA07040L,0xFAD406D4L,0xFAD406D4L,0xFEA07040L,0xFAD406D4L,0xFAD406D4L,0xFEA07040L,0xFAD406D4L};
                int i;
                l_18 = (safe_lshift_func_int32_t_s_s(l_58[2], l_59));
                l_60[4] ^= (65532UL | l_3);
                l_60[7] = l_19.f0;
            }
            else
            { 
                uint16_t l_74 = 0x2D46L;
                int16_t l_78[4] = {0L,0L,0L,0L};
                int32_t l_79 = (-1L);
                int i;
                l_61 ^= l_51;
                l_75 = (((((safe_rshift_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((((safe_lshift_func_int8_t_s_u(((safe_mul_func_uint32_t_u_u((l_20[2].f3 | 0UL), l_19.f2)) < l_20[2].f2), 5)) && 0xDF18L) | l_74), l_20[2].f5)), l_2[1])), l_20[2].f2)) | 2L), l_19.f1)) & l_74) == 1L) & l_55) & l_16);
                l_78[2] = (safe_mod_func_uint16_t_u_u(l_20[2].f4, l_19.f0));
                l_79 = l_40;
            }
            l_80 = l_80;
            for (l_80.f5 = 0; (l_80.f5 <= 2); l_80.f5 += 1)
            { 
                int32_t l_81 = 0L;
                int32_t l_82 = 0x94FA0780L;
                int32_t l_83 = 0xB57A5127L;
                int32_t l_84 = 0x7636F93EL;
                int32_t l_87 = 0x4ADD8BE8L;
                int32_t l_88 = 1L;
                int32_t l_90[5] = {0x42CAA49FL,0x42CAA49FL,0x42CAA49FL,0x42CAA49FL,0x42CAA49FL};
                int i;
                l_100--;
                l_20[l_80.f5] = l_19;
            }
        }
        if (((safe_add_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(l_94, 7)), l_95)) <= 0x74L))
        { 
            l_20[2] = l_20[0];
        }
        else
        { 
            uint32_t l_114 = 6UL;
            int32_t l_122 = 0L;
            for (l_75 = 0; (l_75 < 13); l_75 = safe_add_func_int16_t_s_s(l_75, 5))
            { 
                uint16_t l_113 = 1UL;
                l_2[0] = (safe_sub_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(0x8092L, l_113)), l_114));
            }
            if ((safe_add_func_uint16_t_u_u((l_16 ^ 0x78L), 0x3CAEL)))
            { 
                int32_t l_125 = 0x991CB954L;
                l_122 &= (safe_add_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((((0x33L >= l_114) | l_121) != l_19.f3) ^ l_16), 0x2955A46DL)), 0L));
                l_2[0] ^= l_19.f4;
                l_125 &= ((safe_unary_minus_func_uint16_t_u((0xC9F0A9E8L > l_122))) == l_124[0]);
            }
            else
            { 
                return l_98;
            }
            l_2[2] = l_2[0];
            l_2[0] = l_75;
        }
    }
    return l_19.f2;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 48
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 53
   depth: 2, occurrence: 16
   depth: 3, occurrence: 7
   depth: 4, occurrence: 4
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 83
XXX times a non-volatile is write: 40
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 52
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 17
   depth: 3, occurrence: 28

XXX percentage a fresh-made variable is used: 32.5
XXX percentage an existing variable is used: 67.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

