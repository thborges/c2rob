/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00033.c -s 00033 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      33
 */

#include "csmith.h"


static long __undefined;






static uint32_t  func_1(void);





static uint32_t  func_1(void)
{ 
    uint16_t l_2 = 0xD16DL;
    int32_t l_3[4] = {0x9F4288A1L,0x9F4288A1L,0x9F4288A1L,0x9F4288A1L};
    int32_t l_16 = 1L;
    int i;
    l_2 = 0x4A8C6A53L;
    for (l_2 = 0; (l_2 <= 3); l_2 += 1)
    { 
        uint32_t l_13 = 0UL;
        int32_t l_19 = (-5L);
        int32_t l_20 = (-7L);
        uint16_t l_22 = 0x2E4EL;
        int i;
        if ((safe_add_func_uint16_t_u_u(((safe_mul_func_int64_t_s_s((safe_rshift_func_uint64_t_u_u(0xB61D2250DB856137LL, l_3[l_2])), l_3[l_2])) != l_3[l_2]), l_3[l_2])))
        { 
            int32_t l_10 = 0xD7540573L;
            int32_t l_12 = (-1L);
            for (l_10 = 0; (l_10 <= 3); l_10 += 1)
            { 
                uint16_t l_11 = 0x8900L;
                l_12 = l_11;
                l_13 = l_3[l_2];
                l_16 = (safe_add_func_uint8_t_u_u(l_13, l_12));
            }
        }
        else
        { 
            int16_t l_21 = 0x2715L;
            int32_t l_27[3];
            int i;
            for (i = 0; i < 3; i++)
                l_27[i] = 0x81C5860BL;
            l_16 = (safe_mul_func_int32_t_s_s(l_3[l_2], l_2));
            l_22++;
            if ((safe_rshift_func_int64_t_s_u(l_3[l_2], l_3[1])))
            { 
                int64_t l_32 = 0x7D437F1BD53D2AE4LL;
                l_27[2] = 1L;
                l_27[2] |= (safe_sub_func_int8_t_s_s((safe_div_func_uint8_t_u_u(l_32, l_16)), l_2));
                l_27[2] = (0L <= 0xFA9DFEEE83ADEB94LL);
            }
            else
            { 
                l_27[2] = (-1L);
            }
            l_27[1] = (safe_div_func_uint16_t_u_u((safe_add_func_int16_t_s_s(l_2, 0xA1BAL)), l_21));
        }
        l_16 = (safe_sub_func_uint64_t_u_u((((!(safe_sub_func_int8_t_s_s(l_3[l_2], l_2))) <= l_16) > l_16), l_16));
        for (l_13 = 0; (l_13 <= 3); l_13 += 1)
        { 
            const int64_t l_50 = 0xF62131AC6914F091LL;
            int32_t l_52 = 2L;
            for (l_16 = 0; l_16 < 4; l_16 += 1)
            {
                l_3[l_16] = 0x9025B0D6L;
            }
            for (l_20 = 0; (l_20 <= 3); l_20 += 1)
            { 
                l_19 = ((((l_13 == 0x6AEE34D1L) ^ 0x09L) || l_3[l_2]) <= 0L);
                l_16 = ((safe_div_func_uint8_t_u_u(l_16, 5UL)) <= 0L);
                l_19 = 7L;
            }
            for (l_20 = 3; (l_20 >= 0); l_20 -= 1)
            { 
                int16_t l_51 = (-2L);
                l_52 = (safe_div_func_int64_t_s_s(((((safe_mul_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((l_22 == l_50), l_51)), 0x044BL)) == 0x10L) && l_51) && l_50), 0x512630673EEFD7F9LL));
                l_16 |= l_51;
            }
        }
    }
    for (l_2 = 0; (l_2 < 41); l_2 = safe_add_func_uint32_t_u_u(l_2, 1))
    { 
        uint8_t l_55 = 0x2FL;
        return l_55;
    }
    l_16 = (-1L);
    return l_3[1];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 30
   depth: 2, occurrence: 10
   depth: 3, occurrence: 3
   depth: 5, occurrence: 3
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 24
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 29
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 4
   depth: 2, occurrence: 8
   depth: 3, occurrence: 12

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
XXX total OOB instances added: 0
********************* end of statistics **********************/

