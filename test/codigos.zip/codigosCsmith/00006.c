/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00006.c -s 00006 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      6
 */

#include "csmith.h"


static long __undefined;






static int8_t  func_1(void);





static int8_t  func_1(void)
{ 
    uint64_t l_2 = 0x894801897A4A12B5LL;
    int32_t l_3[7] = {0xA9D19AC1L,0x2FD4914DL,0xA9D19AC1L,0xA9D19AC1L,0x2FD4914DL,0xA9D19AC1L,0xA9D19AC1L};
    uint8_t l_65 = 0x82L;
    int64_t l_81 = 0x1001949225D62391LL;
    int32_t l_113[7] = {0x38B96EC4L,0x38B96EC4L,(-1L),0x38B96EC4L,0x38B96EC4L,(-1L),0x38B96EC4L};
    uint8_t l_173 = 1UL;
    int32_t l_193[4] = {0x747BEB80L,0x747BEB80L,0x747BEB80L,0x747BEB80L};
    const uint16_t l_221[3] = {0UL,0UL,0UL};
    uint16_t l_241[7];
    int i;
    for (i = 0; i < 7; i++)
        l_241[i] = 0xE8E7L;
    l_3[3] = l_2;
    if ((0x41L != l_2))
    { 
        int32_t l_4 = (-1L);
        int32_t l_28 = 0x9892657CL;
        const int32_t l_57 = 0L;
        uint16_t l_77 = 65533UL;
        int32_t l_92[3];
        uint32_t l_107[4] = {0xA0D89505L,0xA0D89505L,0xA0D89505L,0xA0D89505L};
        int i;
        for (i = 0; i < 3; i++)
            l_92[i] = (-1L);
        if (l_4)
        { 
            uint16_t l_5 = 0x9A73L;
            int32_t l_8 = (-1L);
            l_3[3] = ((l_5 != l_5) >= l_4);
            l_8 = (safe_lshift_func_uint16_t_u_u(l_2, 11));
            if (l_8)
            { 
                return l_5;
            }
            else
            { 
                int8_t l_18 = 0x2CL;
                l_8 ^= (l_3[3] != l_2);
                l_8 = ((!(safe_sub_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_div_func_int32_t_s_s(l_4, l_18)), l_4)), l_2)), 252UL))) <= l_18);
            }
        }
        else
        { 
            for (l_4 = (-4); (l_4 < (-18)); l_4 = safe_sub_func_int32_t_s_s(l_4, 1))
            { 
                int64_t l_23 = (-1L);
                l_23 = (safe_mod_func_uint64_t_u_u(0x374489B467BB1A88LL, l_4));
            }
            for (l_4 = (-23); (l_4 > 16); l_4 = safe_add_func_int64_t_s_s(l_4, 1))
            { 
                l_28 |= (safe_add_func_int16_t_s_s((l_4 && (-1L)), 65528UL));
                l_28 ^= (!(safe_div_func_uint16_t_u_u(l_3[3], l_2)));
            }
            for (l_28 = 24; (l_28 == (-20)); l_28 = safe_sub_func_int64_t_s_s(l_28, 4))
            { 
                uint32_t l_34 = 0xC9257018L;
                return l_34;
            }
            l_4 = (l_4 <= 0x0EEBL);
        }
        for (l_28 = 13; (l_28 <= 1); l_28 = safe_sub_func_int32_t_s_s(l_28, 8))
        { 
            uint32_t l_37 = 18446744073709551608UL;
            int32_t l_38 = 0L;
            if (l_37)
            { 
                l_38 |= l_3[3];
            }
            else
            { 
                int32_t l_39 = 0x88B9ABC1L;
                int8_t l_40 = 4L;
                uint32_t l_52[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
                int i;
                l_40 |= ((l_39 < l_2) || l_39);
                l_38 = (((safe_add_func_int32_t_s_s((safe_add_func_int32_t_s_s(((+((safe_lshift_func_int8_t_s_u((safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(l_38, l_39)), l_39)), l_3[2])) != 9UL)) && l_3[3]), 0x996340C0L)), l_39)) > l_52[1]) && l_28);
                l_4 = (safe_sub_func_int32_t_s_s((((safe_mul_func_int16_t_s_s(l_3[6], l_57)) <= l_52[0]) && 0x9DL), l_3[1]));
            }
            for (l_38 = 0; (l_38 <= 6); l_38 += 1)
            { 
                int i;
                l_3[l_38] = l_3[l_38];
                l_4 &= ((safe_lshift_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(((safe_mod_func_int16_t_s_s((!0xC2CFL), l_38)) >= l_3[3]), 0x6B0CL)), l_28)) && l_65);
                l_3[l_38] = (safe_div_func_int64_t_s_s(l_3[l_38], l_3[3]));
            }
        }
        l_28 = (+l_2);
        if (l_65)
        { 
            int64_t l_82 = (-6L);
            int32_t l_83[8] = {0xA8844187L,0xA8844187L,0xA8844187L,0xA8844187L,0xA8844187L,0xA8844187L,0xA8844187L,0xA8844187L};
            uint32_t l_96[9];
            int32_t l_110 = 1L;
            int i;
            for (i = 0; i < 9; i++)
                l_96[i] = 0xF7D18C36L;
            for (l_2 = 19; (l_2 <= 22); l_2 = safe_add_func_int8_t_s_s(l_2, 1))
            { 
                int16_t l_76 = 0x115BL;
                l_76 = ((safe_add_func_uint64_t_u_u(((safe_unary_minus_func_int16_t_s((0x4738L < 8L))) != 0x01105CA7CEE7E287LL), 0x2FD4AE77DDBA47A5LL)) != 0UL);
                l_3[3] = l_2;
                l_77--;
                return l_76;
            }
            l_83[2] = (((!(l_2 >= l_81)) ^ l_82) & 65528UL);
            for (l_77 = 23; (l_77 < 55); l_77 = safe_add_func_int16_t_s_s(l_77, 8))
            { 
                uint8_t l_90[5] = {0UL,0UL,0UL,0UL,0UL};
                int32_t l_91 = (-1L);
                int32_t l_93 = (-7L);
                int32_t l_94 = 0xA9A6AE6CL;
                int32_t l_95 = 0x6A8768DDL;
                int i;
                l_83[5] = (safe_mod_func_uint64_t_u_u((safe_mul_func_uint32_t_u_u(((-1L) & l_90[4]), l_83[2])), 0xE7B049BDD3DE9507LL));
                l_96[6]--;
                l_3[6] = l_96[6];
                l_28 ^= (~(safe_sub_func_int16_t_s_s((((safe_lshift_func_uint8_t_u_s((!(-7L)), 1)) || l_77) ^ l_94), l_95)));
            }
            if ((((safe_add_func_uint8_t_u_u(l_107[1], 0xE9L)) | l_77) > l_96[6]))
            { 
                l_110 |= (((((safe_sub_func_int16_t_s_s(4L, 0x21D2L)) & (-1L)) == l_96[2]) && l_83[5]) == 1UL);
            }
            else
            { 
                int16_t l_120 = 0L;
                int32_t l_121 = 0x62140414L;
                l_113[0] |= ((safe_mod_func_int64_t_s_s((-1L), l_2)) && 0x3CFC5172592CB3A5LL);
                l_121 = (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((l_92[1] || l_96[6]) <= l_120), 18446744073709551614UL)), 1UL)) >= (-1L)), l_28));
                l_4 = 0x922C56DEL;
                l_92[1] ^= ((safe_rshift_func_int16_t_s_u(((safe_add_func_uint8_t_u_u(l_77, l_82)) ^ (-2L)), 3)) >= l_83[2]);
            }
        }
        else
        { 
            int64_t l_133[1];
            int i;
            for (i = 0; i < 1; i++)
                l_133[i] = 0x9CA1EE17268510E3LL;
            l_92[1] = (l_57 <= l_92[2]);
            for (l_81 = 0; (l_81 <= 2); l_81 += 1)
            { 
                int i;
                l_92[l_81] = (safe_div_func_uint8_t_u_u(l_107[(l_81 + 1)], l_92[l_81]));
                l_28 |= 1L;
            }
            for (l_4 = 0; (l_4 <= 2); l_4 += 1)
            { 
                int i;
                l_92[l_4] = l_92[l_4];
                l_28 ^= (~(safe_lshift_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_u(l_133[0], 3)) <= 2UL) ^ l_133[0]), l_92[l_4])));
                l_92[1] = ((0x6471L <= l_133[0]) <= l_3[3]);
                return l_107[1];
            }
        }
    }
    else
    { 
        int64_t l_139 = 6L;
        int32_t l_140 = (-8L);
        int32_t l_147 = 0xFB24A310L;
        int32_t l_157 = 0xC498B4FFL;
        int32_t l_170[4] = {0x7DD60BB7L,0x7DD60BB7L,0x7DD60BB7L,0x7DD60BB7L};
        uint32_t l_176 = 4294967291UL;
        int32_t l_186 = 1L;
        int16_t l_188[10] = {(-1L),0xE7D2L,(-1L),0x65E2L,0x65E2L,(-1L),0xE7D2L,(-1L),0x65E2L,0x65E2L};
        uint32_t l_194 = 0xEB3D4A04L;
        int i;
        l_140 = (((safe_div_func_int32_t_s_s((safe_unary_minus_func_int16_t_s((safe_mod_func_uint32_t_u_u(((l_139 >= l_139) && l_81), l_113[0])))), l_139)) & l_139) | l_139);
        for (l_140 = 6; (l_140 >= 2); l_140 -= 1)
        { 
            int i;
            l_147 &= (safe_div_func_int8_t_s_s(((safe_rshift_func_int64_t_s_s(((safe_mod_func_int64_t_s_s(l_3[l_140], l_113[l_140])) == l_3[l_140]), l_113[l_140])) || 255UL), 255UL));
        }
        for (l_147 = 0; (l_147 > 13); l_147 = safe_add_func_uint32_t_u_u(l_147, 1))
        { 
            int32_t l_150[8];
            int16_t l_192[3];
            int i;
            for (i = 0; i < 8; i++)
                l_150[i] = 0L;
            for (i = 0; i < 3; i++)
                l_192[i] = 0xBFF1L;
            if (((0xCD60AC8F595BA468LL < l_150[4]) || l_139))
            { 
                int32_t l_158 = 0x137E7E5DL;
                l_158 = (safe_mul_func_int64_t_s_s(((safe_div_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(0xE40056FDL, l_140)), l_157)) && l_158), l_150[7]));
                l_113[0] |= ((safe_rshift_func_uint32_t_u_u(l_3[3], 15)) & l_3[3]);
                l_140 ^= ((l_150[4] != 0x93880BEB2AB5F7C5LL) || l_158);
                return l_81;
            }
            else
            { 
                int32_t l_165 = 7L;
                int32_t l_168 = 0xA73A985DL;
                int32_t l_169 = 2L;
                int32_t l_171 = 0x03AC48BBL;
                int32_t l_172[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_172[i] = 0xBADC3C1FL;
                l_140 &= ((safe_sub_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(l_147, l_165)), 0xCBD5L)) < l_3[3]);
                l_140 &= (safe_sub_func_uint16_t_u_u(((0x68L | 0x12L) == l_150[4]), l_165));
                l_173++;
                l_150[4] = l_150[1];
            }
            l_170[2] = l_176;
            l_150[7] = l_150[1];
            if (((safe_div_func_uint8_t_u_u(0xEAL, l_139)) != 0UL))
            { 
                int8_t l_179 = 1L;
                l_150[6] &= l_179;
                l_3[3] = 7L;
                l_150[4] = l_179;
            }
            else
            { 
                int8_t l_180 = 1L;
                int32_t l_181 = 3L;
                int32_t l_182 = 0x91E2C180L;
                int32_t l_183 = 1L;
                int32_t l_184 = (-3L);
                int32_t l_185 = 0x99F85C49L;
                int32_t l_187 = 0xD3118DE8L;
                int32_t l_189 = 0L;
                int32_t l_190[3];
                int16_t l_191 = (-1L);
                int i;
                for (i = 0; i < 3; i++)
                    l_190[i] = 0x5F86D9A3L;
                l_181 = l_180;
                l_194--;
                l_150[6] = (l_194 & 0x619917F2L);
            }
        }
    }
    l_3[3] = (+(safe_sub_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_s(l_113[0], l_193[2])), l_3[3])) > 0xCC00L), l_113[0])));
    if ((((safe_div_func_uint32_t_u_u((+l_113[0]), (-10L))) > 0x255190DBC920AAEBLL) < l_113[0]))
    { 
        const uint8_t l_211[1] = {0UL};
        uint32_t l_212 = 0xD6EEA9B9L;
        int32_t l_213 = 5L;
        int32_t l_214 = (-1L);
        int32_t l_215 = (-1L);
        int32_t l_216[9];
        uint16_t l_217 = 1UL;
        int i;
        for (i = 0; i < 9; i++)
            l_216[i] = 0x1B9BB303L;
        l_113[6] ^= (safe_div_func_uint64_t_u_u((((((safe_add_func_uint32_t_u_u(((((0x6990C9B8L & l_3[6]) <= 0x6582L) <= l_211[0]) > l_212), 0x2D828728L)) ^ l_81) >= 1UL) < 0x07D318FB5AA6BA30LL) == 1L), l_3[3]));
        l_217--;
        l_216[1] |= l_214;
    }
    else
    { 
        int64_t l_220 = 2L;
        uint32_t l_223 = 18446744073709551607UL;
        int16_t l_240 = 1L;
        for (l_81 = 3; (l_81 >= 0); l_81 -= 1)
        { 
            int32_t l_222[6];
            int i;
            for (i = 0; i < 6; i++)
                l_222[i] = 0xD1CC4FA7L;
            l_222[4] |= ((((((0xF902AB11L | l_193[l_81]) || l_220) | l_220) != 0xD3ABL) < l_220) || l_221[2]);
            l_223--;
            for (l_65 = 0; (l_65 <= 3); l_65 += 1)
            { 
                l_113[0] = (((l_222[4] < l_222[0]) < l_193[3]) | l_220);
            }
            l_3[4] = (safe_lshift_func_int64_t_s_u((safe_sub_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((0x54BAL > 0UL) && l_173), l_221[2])), l_3[4])), l_2));
        }
        l_3[6] = (safe_add_func_int16_t_s_s(((((((safe_sub_func_int16_t_s_s(((safe_mul_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((l_220 != 255UL) || 65534UL), l_223)), l_65)) <= 0x42L), l_220)) > 1UL) || l_240) ^ (-10L)) <= 0xC68AE5B8610FE71CLL) < l_241[2]), l_241[2]));
    }
    return l_113[0];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 77
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 95
   depth: 2, occurrence: 23
   depth: 3, occurrence: 9
   depth: 4, occurrence: 7
   depth: 5, occurrence: 7
   depth: 6, occurrence: 5
   depth: 7, occurrence: 3
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 164
XXX times a non-volatile is write: 75
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 90
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 12
   depth: 2, occurrence: 25
   depth: 3, occurrence: 48

XXX percentage a fresh-made variable is used: 22.4
XXX percentage an existing variable is used: 77.6
XXX total OOB instances added: 0
********************* end of statistics **********************/

