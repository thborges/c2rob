/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00008.c -s 00008 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      8
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   unsigned f0 : 18;
   unsigned f1 : 31;
   int64_t  f2;
   signed f3 : 29;
   unsigned f4 : 14;
   int16_t  f5;
   signed f6 : 27;
};





static int8_t  func_1(void);





static int8_t  func_1(void)
{ 
    uint8_t l_2[4];
    int32_t l_3 = (-1L);
    int32_t l_7 = 0x3C407858L;
    const struct S0 l_11[3] = {{357,34277,0x07C70AB227D373EELL,-17481,99,4L,-1506},{357,34277,0x07C70AB227D373EELL,-17481,99,4L,-1506},{357,34277,0x07C70AB227D373EELL,-17481,99,4L,-1506}};
    int i;
    for (i = 0; i < 4; i++)
        l_2[i] = 255UL;
    for (l_3 = 0; (l_3 <= 3); l_3 += 1)
    { 
        int32_t l_4[6] = {0L,0L,0L,0L,0L,0L};
        int32_t l_5 = 0xD26EC17EL;
        int32_t l_6 = 0L;
        struct S0 l_12[5] = {{355,11935,0xFD52280335900B08LL,-4700,109,-2L,8204},{355,11935,0xFD52280335900B08LL,-4700,109,-2L,8204},{355,11935,0xFD52280335900B08LL,-4700,109,-2L,8204},{355,11935,0xFD52280335900B08LL,-4700,109,-2L,8204},{355,11935,0xFD52280335900B08LL,-4700,109,-2L,8204}};
        int i;
        for (l_4[4] = 0; (l_4[4] <= 3); l_4[4] += 1)
        { 
            uint16_t l_8 = 65526UL;
            l_8--;
            l_5 &= 3L;
        }
        l_12[3] = l_11[0];
        for (l_5 = 0; (l_5 <= 3); l_5 += 1)
        { 
            uint16_t l_13 = 1UL;
            for (l_7 = 3; (l_7 >= 0); l_7 -= 1)
            { 
                int32_t l_18 = 0x12D49381L;
                int i;
                l_13 = 0L;
                l_12[3].f3 = (safe_add_func_int64_t_s_s((l_2[l_5] ^ 4L), 18446744073709551606UL));
                l_18 = (safe_add_func_int64_t_s_s(l_2[l_3], 1UL));
            }
            for (l_7 = 3; (l_7 >= 0); l_7 -= 1)
            { 
                int i;
                l_4[l_3] = (((3L && l_2[l_7]) == l_4[l_7]) < 0x2FC9L);
            }
        }
        l_12[1] = l_11[2];
    }
    return l_7;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 5
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 2
breakdown:
   indirect level: 0, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 2
XXX times a bitfields struct on RHS: 2
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 12
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 4
   depth: 2, occurrence: 4
   depth: 3, occurrence: 4

XXX percentage a fresh-made variable is used: 61.5
XXX percentage an existing variable is used: 38.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

