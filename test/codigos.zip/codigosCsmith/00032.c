/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00032.c -s 00032 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      32
 */

#include "csmith.h"


static long __undefined;






static int16_t  func_1(void);





static int16_t  func_1(void)
{ 
    const int8_t l_2 = 0xA4L;
    uint8_t l_3 = 1UL;
    int32_t l_4 = 0xAB3E90A6L;
    int32_t l_11[4];
    int32_t l_17 = 2L;
    int16_t l_18 = 1L;
    int i;
    for (i = 0; i < 4; i++)
        l_11[i] = (-1L);
    l_4 = (l_2 & l_3);
    for (l_3 = 27; (l_3 == 4); l_3 = safe_sub_func_uint32_t_u_u(l_3, 8))
    { 
        int64_t l_7 = 2L;
        int32_t l_8 = 2L;
        int32_t l_9 = 0xD9EDBDA7L;
        int32_t l_10 = 0xA8D3A18EL;
        int32_t l_12 = 0x8E17C109L;
        int64_t l_13 = (-3L);
        int32_t l_14 = 9L;
        int32_t l_15 = 0x85E0710DL;
        int32_t l_16[7] = {1L,1L,1L,1L,1L,1L,1L};
        uint16_t l_19[1];
        int16_t l_22 = 0x40C3L;
        int i;
        for (i = 0; i < 1; i++)
            l_19[i] = 0x07EAL;
        l_19[0]++;
        return l_22;
    }
    return l_17;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 5
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 45.9
XXX percentage an existing variable is used: 54.1
XXX total OOB instances added: 0
********************* end of statistics **********************/

