/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00016.c -s 00016 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      16
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   uint32_t  f0;
   int64_t  f1;
   uint8_t  f2;
};





static int32_t  func_1(void);





static int32_t  func_1(void)
{ 
    uint32_t l_2 = 0UL;
    int32_t l_3 = 0xAFBBD0A7L;
    int32_t l_15 = 0x1AFEC1E1L;
    int8_t l_16[10] = {0L,(-10L),0xEDL,0xEDL,(-10L),0L,(-10L),0xEDL,0xEDL,(-10L)};
    uint8_t l_35[5] = {0xDBL,0xDBL,0xDBL,0xDBL,0xDBL};
    struct S0 l_37 = {0UL,0L,0xE5L};
    uint32_t l_38 = 4UL;
    int i;
    l_2 = 0xCCCDDD1DL;
    l_3 = (0x205BL & l_2);
    for (l_3 = 0; (l_3 == (-5)); l_3 = safe_sub_func_int8_t_s_s(l_3, 1))
    { 
        int8_t l_8[1];
        uint64_t l_11 = 0x637B30477AE2718BLL;
        int32_t l_17 = (-1L);
        struct S0 l_36[8] = {{0x2BF6251CL,0x2AE39B9AA6B35ED3LL,251UL},{0UL,-1L,0xACL},{0x2BF6251CL,0x2AE39B9AA6B35ED3LL,251UL},{0UL,-1L,0xACL},{0x2BF6251CL,0x2AE39B9AA6B35ED3LL,251UL},{0UL,-1L,0xACL},{0x2BF6251CL,0x2AE39B9AA6B35ED3LL,251UL},{0UL,-1L,0xACL}};
        int i;
        for (i = 0; i < 1; i++)
            l_8[i] = 0x27L;
        if ((((((safe_sub_func_uint64_t_u_u((((((l_3 >= 9L) ^ l_8[0]) ^ l_8[0]) == 0x61L) >= l_8[0]), l_2)) ^ l_8[0]) <= l_8[0]) != l_8[0]) != l_2))
        { 
            uint16_t l_12 = 0xD033L;
            int8_t l_14[3];
            uint8_t l_28 = 254UL;
            int32_t l_30 = (-10L);
            int i;
            for (i = 0; i < 3; i++)
                l_14[i] = 0xBBL;
            if (((safe_lshift_func_int8_t_s_s(((((l_2 >= l_11) == 0x28EAF6082F4E55B6LL) & l_12) >= l_12), 5)) < l_8[0]))
            { 
                int32_t l_27 = 1L;
                int32_t l_29 = (-10L);
                l_14[2] = ((safe_unary_minus_func_uint32_t_u(0xA7221EBCL)) & l_12);
                l_15 = l_2;
                l_17 &= ((1UL != l_16[6]) ^ l_12);
                l_29 = (safe_div_func_int8_t_s_s(((safe_div_func_uint8_t_u_u((((safe_lshift_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((+((l_27 > l_16[3]) & l_27)), 1UL)), 20)) != l_16[6]) != l_28), 0x1CL)) != l_3), l_16[6]));
            }
            else
            { 
                int32_t l_34 = 0x784865E5L;
                l_30 = l_8[0];
                l_17 = (safe_add_func_int32_t_s_s((l_8[0] == 1UL), l_28));
                l_15 = ((!0UL) & l_34);
                l_17 = l_35[0];
            }
        }
        else
        { 
            l_37 = l_36[4];
        }
        l_38 |= l_3;
    }
    return l_37.f2;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 35
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 2
   depth: 2, occurrence: 2
   depth: 3, occurrence: 8

XXX percentage a fresh-made variable is used: 39.1
XXX percentage an existing variable is used: 60.9
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

