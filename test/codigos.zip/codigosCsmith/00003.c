/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00003.c -s 00003 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      3
 */

#include "csmith.h"


static long __undefined;






static int32_t  func_1(void);





static int32_t  func_1(void)
{ 
    int32_t l_2[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint64_t l_8 = 6UL;
    int32_t l_19[1];
    uint32_t l_20 = 0x8AF066B7L;
    int i;
    for (i = 0; i < 1; i++)
        l_19[i] = 0x489F7A9DL;
    for (l_2[5] = 0; (l_2[5] != (-2)); l_2[5] = safe_sub_func_uint16_t_u_u(l_2[5], 1))
    { 
        int32_t l_7 = 0xF9E923E6L;
        int32_t l_9[9];
        uint32_t l_12 = 0xF09A2B44L;
        int i;
        for (i = 0; i < 9; i++)
            l_9[i] = 4L;
        l_8 = (safe_rshift_func_int8_t_s_s((l_7 || l_7), l_7));
        for (l_8 = 2; (l_8 <= 8); l_8 += 1)
        { 
            int32_t l_13 = 0x0A4BA31EL;
            int i;
            l_13 ^= (((safe_add_func_int16_t_s_s(l_9[l_8], l_8)) < (-1L)) <= l_12);
            for (l_7 = 0; (l_7 < (-15)); l_7--)
            { 
                l_19[0] = (safe_div_func_int16_t_s_s((~(0x1D6A56C3L > 0x0549EC71L)), 0x7F08L));
                return l_19[0];
            }
        }
    }
    return l_20;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 2
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2

XXX percentage a fresh-made variable is used: 60
XXX percentage an existing variable is used: 40
XXX total OOB instances added: 0
********************* end of statistics **********************/

