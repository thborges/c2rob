/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00039.c -s 00039 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      39
 */

#include "csmith.h"


static long __undefined;






static const int32_t  func_1(void);





static const int32_t  func_1(void)
{ 
    int16_t l_2 = 0x9D43L;
    int32_t l_3 = 0xB2B74C38L;
    const int16_t l_10 = (-9L);
    int8_t l_15 = 0x4CL;
    int32_t l_16 = 1L;
    l_3 |= (l_2 || l_2);
    l_3 = ((safe_lshift_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(l_3, l_3)), l_3)) >= l_2);
    for (l_2 = 22; (l_2 != (-17)); l_2 = safe_sub_func_uint8_t_u_u(l_2, 1))
    { 
        return l_10;
    }
    l_16 |= ((((safe_mul_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_s(l_15, l_10)) < l_3), l_3)) ^ l_15) == 0x8D7DL) || l_10);
    return l_16;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 5
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 2
   depth: 4, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 29.4
XXX percentage an existing variable is used: 70.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

