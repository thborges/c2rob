/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00023.c -s 00023 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      23
 */

#include "csmith.h"


static long __undefined;






static const uint8_t  func_1(void);





static const uint8_t  func_1(void)
{ 
    int32_t l_2 = 0xB9F9B319L;
    int32_t l_13[4];
    int32_t l_14[5];
    int i;
    for (i = 0; i < 4; i++)
        l_13[i] = 4L;
    for (i = 0; i < 5; i++)
        l_14[i] = (-3L);
    for (l_2 = 0; (l_2 > (-28)); l_2--)
    { 
        int32_t l_5 = 0xAFD94FE5L;
        l_5 |= (1L & l_2);
        for (l_5 = 0; (l_5 >= 16); l_5 = safe_add_func_uint64_t_u_u(l_5, 1))
        { 
            int32_t l_10[7] = {1L,(-1L),1L,1L,(-1L),1L,1L};
            int32_t l_11 = 7L;
            int32_t l_12 = 0x00868BB4L;
            int i;
            l_12 |= ((safe_lshift_func_uint32_t_u_u(l_10[4], 9)) | l_11);
        }
    }
    for (l_2 = 3; (l_2 >= 0); l_2 -= 1)
    { 
        int i;
        l_14[1] ^= l_13[l_2];
    }
    if ((safe_sub_func_int8_t_s_s(l_13[3], (-1L))))
    { 
        uint8_t l_18 = 0x1CL;
        int32_t l_25 = 0x8D10FBF2L;
        int32_t l_31 = 2L;
        int32_t l_32 = (-1L);
        int32_t l_33[5] = {0L,0L,0L,0L,0L};
        uint16_t l_34 = 65526UL;
        int i;
        for (l_2 = 3; (l_2 >= 0); l_2 -= 1)
        { 
            const int8_t l_17 = 0L;
            return l_17;
        }
        l_18 = l_14[2];
        for (l_18 = 21; (l_18 != 36); l_18 = safe_add_func_uint16_t_u_u(l_18, 5))
        { 
            uint16_t l_21[4];
            int32_t l_30[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            for (i = 0; i < 4; i++)
                l_21[i] = 0x5F5AL;
            if ((l_18 <= l_21[1]))
            { 
                const int32_t l_24 = 5L;
                l_14[1] = (safe_sub_func_int16_t_s_s(0xA198L, l_24));
                l_25 = (((-3L) > l_13[2]) >= 0x4F2A6CA0L);
                l_30[0] ^= (safe_add_func_int64_t_s_s((safe_mul_func_uint64_t_u_u(l_25, 0x76DF3E2E16658069LL)), 0xFE905687C4177FD8LL));
                l_30[0] ^= ((l_24 && 18446744073709551606UL) != l_13[2]);
            }
            else
            { 
                l_34--;
            }
        }
        for (l_2 = 0; (l_2 > (-1)); l_2 = safe_sub_func_int8_t_s_s(l_2, 1))
        { 
            uint16_t l_39 = 65527UL;
            l_25 = (0x568C0775DAE11CD4LL || 3UL);
            l_39 = 0x430F0C86L;
        }
    }
    else
    { 
        int16_t l_46 = 3L;
        for (l_2 = (-17); (l_2 < 0); l_2 = safe_add_func_int64_t_s_s(l_2, 1))
        { 
            int16_t l_47 = (-1L);
            l_14[0] = ((((safe_div_func_int64_t_s_s(((safe_add_func_int64_t_s_s(l_46, l_13[0])) & l_46), 0x6322A57D884BB868LL)) < l_14[1]) & 0xFAL) <= l_47);
        }
    }
    return l_2;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 12
   depth: 3, occurrence: 4
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 27
XXX times a non-volatile is write: 19
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 23
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 8
   depth: 2, occurrence: 6
   depth: 3, occurrence: 5

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
XXX total OOB instances added: 0
********************* end of statistics **********************/

