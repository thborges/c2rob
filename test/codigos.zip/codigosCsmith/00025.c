/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00025.c -s 00025 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      25
 */

#include "csmith.h"


static long __undefined;






static const int8_t  func_1(void);





static const int8_t  func_1(void)
{ 
    uint64_t l_5 = 18446744073709551613UL;
    const uint32_t l_6 = 0xE1C97412L;
    int32_t l_7 = 0xC13FE662L;
    int32_t l_16 = 0x40E13F5EL;
    int32_t l_17[8];
    int64_t l_18 = 7L;
    int16_t l_19 = 0x0A10L;
    uint32_t l_20 = 0UL;
    int i;
    for (i = 0; i < 8; i++)
        l_17[i] = 0x9F4F9A02L;
    l_7 = (!(((safe_mul_func_int16_t_s_s((((((l_5 & l_5) != l_5) | l_6) == l_5) || l_6), l_5)) < l_5) && l_6));
    l_7 = (safe_mod_func_int16_t_s_s((safe_div_func_int16_t_s_s((safe_div_func_int64_t_s_s((l_7 > 0xFD43L), l_5)), l_7)), l_6));
    l_16 ^= (((safe_mod_func_int16_t_s_s(l_6, l_7)) > l_6) < l_6);
    l_20++;
    return l_19;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 6
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 18
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 5

XXX percentage a fresh-made variable is used: 14.8
XXX percentage an existing variable is used: 85.2
XXX total OOB instances added: 0
********************* end of statistics **********************/

