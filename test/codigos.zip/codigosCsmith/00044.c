/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00044.c -s 00044 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      44
 */

#include "csmith.h"


static long __undefined;


struct S0 {
   signed f0 : 4;
   unsigned f1 : 9;
   const signed f2 : 7;
   signed f3 : 23;
   const signed f4 : 10;
};





static struct S0  func_1(void);





static struct S0  func_1(void)
{ 
    uint32_t l_2 = 18446744073709551614UL;
    int32_t l_3 = (-8L);
    int32_t l_6 = 0xFE8B0D19L;
    uint8_t l_7 = 0x72L;
    int8_t l_8 = 0x0FL;
    int32_t l_26[4];
    struct S0 l_28 = {-3,0,-6,651,-12};
    int i;
    for (i = 0; i < 4; i++)
        l_26[i] = (-10L);
    l_3 = l_2;
    l_8 = ((safe_add_func_uint64_t_u_u((l_2 > l_6), l_7)) > l_7);
    for (l_3 = 28; (l_3 != 28); l_3 = safe_add_func_uint32_t_u_u(l_3, 6))
    { 
        int16_t l_13 = 1L;
        int32_t l_14[2];
        int i;
        for (i = 0; i < 2; i++)
            l_14[i] = 0xB6DAD816L;
        if (((safe_lshift_func_uint16_t_u_s(l_13, 4)) > 0UL))
        { 
            l_14[1] = l_8;
            l_14[1] = ((0x0270L | 0L) < 0xAAL);
            for (l_8 = 1; (l_8 >= 0); l_8 -= 1)
            { 
                int i;
                l_14[l_8] &= 1L;
                l_14[l_8] = (safe_mul_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((((((l_14[l_8] ^ l_14[1]) >= 0x48L) == l_3) || 0x30B63E91CB64B693LL) == l_14[l_8]) > (-1L)), 0x6293L)) && 0x0105807C1ABDF11CLL), 0x2CD8L));
            }
        }
        else
        { 
            int64_t l_21 = (-2L);
            int32_t l_27 = 0xE01153AAL;
            for (l_2 = 0; (l_2 >= 14); l_2 = safe_add_func_uint32_t_u_u(l_2, 3))
            { 
                uint64_t l_22 = 0x4B13B1067DCC3592LL;
                int32_t l_23 = 0x9D707D8EL;
                l_14[0] &= l_21;
                l_23 = (l_14[1] != l_22);
                l_27 = (((safe_add_func_uint16_t_u_u(l_21, 1UL)) == l_22) >= l_26[2]);
                l_23 = 0x41209775L;
            }
            l_6 = (l_13 < l_13);
        }
    }
    return l_28;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 5
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 2
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 1
breakdown:
   indirect level: 0, occurrence: 1
XXX full-bitfields structs in the program: 1
breakdown:
   indirect level: 0, occurrence: 1
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 1
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 14
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 1
   depth: 2, occurrence: 5
   depth: 3, occurrence: 6

XXX percentage a fresh-made variable is used: 46.4
XXX percentage an existing variable is used: 53.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

