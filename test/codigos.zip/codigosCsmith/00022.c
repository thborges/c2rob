/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00022.c -s 00022 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      22
 */

#include "csmith.h"


static long __undefined;


struct S2 {
   uint8_t  f0;
   signed f1 : 20;
   signed f2 : 10;
   signed f3 : 21;
   unsigned f4 : 24;
   unsigned f5 : 30;
   unsigned f6 : 16;
};





static const int32_t  func_1(void);





static const int32_t  func_1(void)
{ 
    int32_t l_2 = (-1L);
    struct S2 l_29[9] = {{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144},{254UL,-299,18,-488,2175,5005,144}};
    int i;
    for (l_2 = 0; (l_2 <= 22); l_2 = safe_add_func_uint64_t_u_u(l_2, 4))
    { 
        uint32_t l_8 = 0xA32FD2D1L;
        int32_t l_9[7];
        int i;
        for (i = 0; i < 7; i++)
            l_9[i] = (-1L);
        l_9[0] &= (((safe_unary_minus_func_int8_t_s((safe_div_func_int64_t_s_s((-1L), l_8)))) ^ l_8) || l_8);
        for (l_8 = 25; (l_8 == 31); l_8 = safe_add_func_uint32_t_u_u(l_8, 1))
        { 
            int32_t l_17 = (-1L);
            int32_t l_18 = 0x8376FBFCL;
            struct S2 l_30 = {0UL,-791,-0,-855,2362,19637,222};
            const int16_t l_34 = 0xC6A0L;
            uint32_t l_35 = 0x1C74F348L;
            if (((l_2 > l_2) || l_9[0]))
            { 
                uint16_t l_12 = 65535UL;
                l_12 = 0L;
            }
            else
            { 
                const int64_t l_19 = 9L;
                l_18 = (safe_sub_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(l_9[4], l_17)), l_8));
                l_9[2] = l_19;
                return l_9[0];
            }
            for (l_17 = (-15); (l_17 > 8); l_17 = safe_add_func_uint64_t_u_u(l_17, 1))
            { 
                return l_9[0];
            }
            l_9[1] = (+(safe_rshift_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(((0xDF47L || l_18) != 0x21589AFCL), 0x6293L)), 2)));
            if ((safe_rshift_func_int64_t_s_s((4294967289UL < 0xF890BA5FL), 48)))
            { 
                l_30 = l_29[4];
                l_30.f1 ^= 0L;
                l_29[4] = l_29[3];
            }
            else
            { 
                int8_t l_33 = 0x11L;
                l_35 ^= ((safe_div_func_uint16_t_u_u(((l_9[0] >= l_33) != 2L), 0xA2CCL)) && l_34);
            }
        }
        return l_9[0];
    }
    return l_29[4].f5;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 6
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 2
breakdown:
   indirect level: 0, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 2
XXX times a bitfields struct on RHS: 2
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 1

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 3
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 18
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 3
   depth: 2, occurrence: 4
   depth: 3, occurrence: 9

XXX percentage a fresh-made variable is used: 37.9
XXX percentage an existing variable is used: 62.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

