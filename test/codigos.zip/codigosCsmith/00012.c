/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00012.c -s 00012 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      12
 */

#include "csmith.h"


static long __undefined;






static const uint64_t  func_1(void);





static const uint64_t  func_1(void)
{ 
    uint32_t l_8 = 0UL;
    int32_t l_9 = 0L;
    int32_t l_10 = 1L;
    int32_t l_11 = (-8L);
    int32_t l_12[4];
    int32_t l_13 = 0x70F9E3D3L;
    uint32_t l_14[4];
    int i;
    for (i = 0; i < 4; i++)
        l_12[i] = 0xFECF7921L;
    for (i = 0; i < 4; i++)
        l_14[i] = 0xECB2EC6FL;
    l_9 = (((safe_mul_func_uint64_t_u_u(((safe_sub_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u((l_8 == l_8), l_8)) || 255UL), l_8)) < l_8), l_8)) && l_8) && l_8);
    l_14[2]--;
    l_9 ^= l_12[0];
    return l_9;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 6
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 4
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 4

XXX percentage a fresh-made variable is used: 9.09
XXX percentage an existing variable is used: 90.9
XXX total OOB instances added: 0
********************* end of statistics **********************/

