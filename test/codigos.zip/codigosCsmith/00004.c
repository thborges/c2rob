/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00004.c -s 00004 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      4
 */

#include "csmith.h"


static long __undefined;






static int8_t  func_1(void);





static int8_t  func_1(void)
{ 
    int32_t l_2 = 8L;
    uint32_t l_8[3];
    uint32_t l_24 = 4294967289UL;
    int32_t l_25 = 0xDAE89405L;
    int i;
    for (i = 0; i < 3; i++)
        l_8[i] = 18446744073709551613UL;
    for (l_2 = 0; (l_2 < 27); l_2 = safe_add_func_int8_t_s_s(l_2, 4))
    { 
        int16_t l_7 = 0x91CBL;
        int32_t l_11 = 0xE3CA3691L;
        int16_t l_35 = 0x2010L;
        const uint32_t l_38 = 0x7A0786CBL;
        if ((safe_mul_func_uint32_t_u_u((l_7 | l_2), l_2)))
        { 
            int16_t l_18 = 0x1EE6L;
            int32_t l_29[4];
            int i;
            for (i = 0; i < 4; i++)
                l_29[i] = (-7L);
            for (l_7 = 2; (l_7 >= 0); l_7 -= 1)
            { 
                int32_t l_10 = 3L;
                int i;
                l_10 = ((safe_unary_minus_func_uint32_t_u(l_8[l_7])) < 0UL);
                l_11 = (((l_8[l_7] != l_8[l_7]) >= l_10) == 0xC8B1L);
            }
            if ((safe_sub_func_int64_t_s_s((safe_div_func_int32_t_s_s((((safe_mul_func_int16_t_s_s((4UL <= l_2), l_18)) == 0L) && 0x6EL), l_8[0])), l_8[1])))
            { 
                const uint16_t l_23 = 1UL;
                int64_t l_28 = 0xC83B91359A7032F1LL;
                l_25 ^= (safe_div_func_int64_t_s_s((safe_mul_func_uint8_t_u_u(((l_23 > 0x725FC1C5L) == 0x11ECBFCF419C2B2ELL), l_7)), l_24));
                l_29[2] = (safe_sub_func_uint64_t_u_u((l_24 && l_23), l_28));
                l_11 = ((safe_div_func_uint64_t_u_u(((l_29[0] > l_23) ^ l_29[2]), l_25)) <= 0UL);
            }
            else
            { 
                uint8_t l_34[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_34[i] = 0x67L;
                l_29[0] = (-1L);
                l_11 ^= l_18;
                l_11 = (((-6L) | l_11) && 0xFF7828E972CE3C48LL);
                l_11 = (safe_rshift_func_uint8_t_u_s(((((l_8[0] ^ l_24) != l_11) == l_8[1]) != l_34[0]), l_35));
            }
            for (l_18 = 2; (l_18 >= 0); l_18 -= 1)
            { 
                int i;
                l_25 = l_8[l_18];
                return l_29[(l_18 + 1)];
            }
        }
        else
        { 
            return l_2;
        }
        l_11 = (((safe_sub_func_int8_t_s_s(l_35, l_8[1])) > l_11) & l_38);
    }
    l_25 = (safe_mod_func_int32_t_s_s((l_2 < l_25), 4294967295UL));
    return l_8[1];
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 4
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 42
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4
   depth: 3, occurrence: 11

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

