/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 0ec6f1b
 * Options:   -o cfiles/00001.c -s 00001 --probability-configuration csmith.prob --quiet --max-funcs 1 --max-array-dim 1 --no-jumps --no-argc --no-unions --no-pointers --no-packed-struct --no-pre-incr-operator --no-pre-decr-operator --no-global-variables --no-embedded-assigns --no-comma-operators --max-expr-complexity 2 --max-block-depth 3
 * Seed:      1
 */

#include "csmith.h"


static long __undefined;






static const int32_t  func_1(void);





static const int32_t  func_1(void)
{ 
    int32_t l_2 = 1L;
    int16_t l_15[6];
    int32_t l_16 = 0x8B4DFECBL;
    int32_t l_17 = 0x150FAEB3L;
    int32_t l_18 = 0x99740826L;
    int32_t l_19 = 1L;
    uint16_t l_40 = 0UL;
    int i;
    for (i = 0; i < 6; i++)
        l_15[i] = 0L;
    for (l_2 = 0; (l_2 < 12); l_2 = safe_add_func_uint8_t_u_u(l_2, 4))
    { 
        int32_t l_5 = 0x16DF251DL;
        for (l_5 = 3; (l_5 < (-7)); l_5 = safe_sub_func_uint16_t_u_u(l_5, 1))
        { 
            uint32_t l_8[6] = {18446744073709551607UL,3UL,18446744073709551607UL,18446744073709551607UL,3UL,18446744073709551607UL};
            int32_t l_9 = 0xE4B28306L;
            int i;
            for (l_9 = 5; (l_9 >= 0); l_9 -= 1)
            { 
                int32_t l_12 = (-5L);
                l_12 = (safe_lshift_func_uint16_t_u_u(0x3717L, 14));
            }
        }
        l_5 = (((safe_div_func_uint8_t_u_u(l_5, 0xA6L)) | l_2) >= l_5);
        l_5 = ((l_2 > l_5) && l_5);
    }
    for (l_2 = 0; (l_2 <= 5); l_2 += 1)
    { 
        uint64_t l_20 = 0x56E31BB000E2E4EDLL;
        int32_t l_25 = 5L;
        int i;
        l_20++;
        l_25 = (safe_add_func_uint8_t_u_u(l_15[l_2], l_15[l_2]));
    }
    for (l_2 = 0; (l_2 == 18); l_2 = safe_add_func_int32_t_s_s(l_2, 1))
    { 
        return l_15[0];
    }
    l_18 = ((safe_add_func_int32_t_s_s((safe_mod_func_int64_t_s_s((safe_div_func_uint64_t_u_u((~(safe_sub_func_int16_t_s_s((((((!l_40) & l_2) >= (-1L)) == l_16) >= (-1L)), l_19))), l_40)), l_18)), l_40)) < 0L);
    return l_16;
}





int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 7
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 11
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 6
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1

XXX percentage a fresh-made variable is used: 30.8
XXX percentage an existing variable is used: 69.2
XXX total OOB instances added: 0
********************* end of statistics **********************/

